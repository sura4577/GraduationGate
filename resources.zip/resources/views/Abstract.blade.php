@include('includes.head')

<body class=" leading-normal tracking-normal bg-[#F0F3F4] min-h-screen flex flex-col ">
  <!--Nav-->
  @include('includes.header')

<nav class="flex mb-4 mx-3 my-2" aria-label="Breadcrumb">
  <ol class="inline-flex items-center space-x-1 md:space-x-3">
    <li class="inline-flex items-center">
    @auth
      <a href="{{ url('/HomeAsGPC') }}" class="inline-flex items-center text-sm font-medium text-cyan-950  underline  "> 
        Home
      </a>
      @endauth
      @guest
      <a href="{{ url('/') }}" class="inline-flex items-center text-sm font-medium text-cyan-950  underline  "> 
        Home
      </a>
      @endguest

    </li>
      <li>
        <div class="flex items-center">
          <svg class="w-3 h-3 text-[#005299] mx-1" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 6 10">
            <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m1 9 4-4-4-4" />
          </svg>
          <a href="{{ url('/showProjects') }}" class="ml-1 text-sm font-medium text-cyan-950  underline   md:ml-2">Archive</a>
        </div>
      </li>
      <li aria-current="page">
        <div class="flex items-center">
          <svg class="w-3 h-3 text-[#005299] mx-1" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 6 10">
            <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m1 9 4-4-4-4" />
          </svg>
          <span class="ml-1 text-sm font-medium text-[#0891B2] md:ml-2 ">Abstract</span>
        </div>
      </li>
    </ol>
  </nav>

  
  <!-- ptoject section -->
  <div class=" w-full md:w-12/12 h-full mx-auto text-sm  flex-grow">
    <!-- project Body -->
    <div class=" w-11/12 md:w-9/12 bg-white border-soild rounded-lg  border-b-2 border-b-cyan-950  px-4 my-0 mx-auto pb-4">
    <div class="flex flex-wrap justify-end mb-1 p-1 border-b-2 border-b-stone-200">
    @php
        $w_text = ' ';
        $currentURL = url()->current(); 
    @endphp

    <div class="relative group">
    <button id="shareButton" class="text-cyan-950 bg-stone-300 py-1 px-2 text-md capitalize m-1 rounded-sm items-center font-serif hover:bg-cyan-950 hover:text-white focus:outline-none">
        <i class="fa fa-share text-cyan-600" aria-hidden="true"></i> Share
    </button>

    <div id="shareMenu" class="absolute hidden bg-white w-48 text-cyan-950 mt-2 rounded-lg shadow-lg">
        <a href="#" class="block py-2 px-4 hover:bg-cyan-950 hover:text-white" onclick="shareOnWhatsApp()">
        <i class="fa fa-whatsapp fa-sm mr-1 text-green-600" aria-hidden="true"></i> WhatsApp
        </a>
        <a href="#" class="block py-2 px-4 hover:bg-cyan-950 hover:text-white" onclick="shareByEmail()">
        <i class="fa fa-envelope fa-sm text-cyan-600 mr-1 " aria-hidden="true"></i> Email
        </a>
        <!-- Add more options for other platforms -->

        <!-- Your existing buttons (download, favorite, etc.) -->

    </div>
</div>

<script>
    document.getElementById('shareButton').addEventListener('click', function () {
        document.getElementById('shareMenu').classList.toggle('hidden');
    });

    function shareOnWhatsApp() {
        var text = encodeURIComponent(' ' + ' ' + window.location.href);
        var whatsappURL = 'https://api.whatsapp.com/send?text=' + text;
        window.open(whatsappURL, '_blank');
    }

    function shareByEmail() {
        var subject = encodeURIComponent('Your email subject here');
        var body = encodeURIComponent(' ' + ' ' + window.location.href);
        var emailURL = 'mailto:?subject=' + subject + '&body=' + body;
        window.open(emailURL, '_blank');
    }

    // Add more functions for other platforms if needed
</script>


    @auth
        <a href="{{$project->url}}" class="text-cyan-950 bg-stone-300 py-1 px-2 text-md decoration-0 capitalize m-1 rounded-sm items-center font-serif hover:bg-cyan-950 hover:text-white">
            <i class="fa fa-download text-cyan-600 mr-1" aria-hidden="true"></i> Download
        </a>

        @php
            $favourite_project = DB::table('favourite_project')
                ->where('created_by', auth()->user()->id)
                ->where('project_id', $project->id)
                ->orderby('created_at', 'desc') // Change ordering to created_at
                ->first();

            // Initialize other variables
            $favouriteUrl = '';
            $text = '';
            $backgroundColor = '';
            $starColor = ''; // New variable to set the color of the star icon

            if (isset($favourite_project)) {
                $favouriteUrl = route('remove.fav', ['id' => $favourite_project->project_id, 'r_proj' => 'abstract']);
                $backgroundColor = 'bg-red-800';
                $starColor = 'text-white'; // Set the color to white when the project is a favorite
            } else {
                $favouriteUrl = route('favouriteProject', ['id' => $project->id]);
                $text = 'Add to favorite';
                $backgroundColor = 'bg-stone-300';
            }
        @endphp

        <a href="{{ $favouriteUrl }}" class="text-cyan-950 {{ $backgroundColor }} py-1 px-2 text-md decoration-0 capitalize m-1 rounded-sm items-center font-serif hover:bg-cyan-950 hover:text-white">
            <i class="fa fa-star {{ $starColor }} text-cyan-600" aria-hidden="true"></i>
        </a>

        @if(auth()->user()->user_type == 'admin')
            <a onclick="return confirm('Are You Sure To Delete')" href="{{ route('delProjects',['id'=>$project->id]) }}" class="text-cyan-950 bg-stone-300 py-1 px-2 text-md decoration-0 capitalize m-1 rounded-sm items-center font-serif hover:bg-cyan-950 hover:text-white">
                <i class="fa fa-trash text-cyan-600" aria-hidden="true"></i>
            </a>
        @endif
    @else
        <a href="{{ route('login') }}" class="text-cyan-950 bg-stone-300 py-1 px-2 text-md decoration-0 capitalize m-1 rounded-sm items-center font-serif hover:bg-cyan-950 hover:text-white">
            <i class="fa fa-download text-cyan-600" aria-hidden="true"></i> Download
        </a>
        <a href="{{ route('login') }}"  class="text-cyan-950 bg-stone-300  py-1 px-2 text-md decoration-0 capitalize m-1 rounded-sm items-center font-serif hover:bg-cyan-950 hover:text-white">
            <i class="fa fa-star text-cyan-600" aria-hidden="true"></i>
        </a>
    @endauth
</div>

      <div class="  flex flex-wrap w-full p-1  ">

        <div class=" w-11/12 md:w-8/12 p-1">
          <h3 class=" text-cyan-950 capitalize text-lg font-bold">{{$project->name}}</h3>
          <p class="p-2  border-b-2 md:border-b-0 md:border-r-2 md:border-stone-200 text-stone-600 text-md font-serif">{{$project->narration}}</p>
        </div>


        <div class="w-full md:w-4/12 py-1 px-3 ">
          <div class="pt-2 md:pt-8 text-cyan-950 ">
            <h3 class="text-left text-stone-800 text-md font-bold">Information</h3>
          </div> <!-- End header-section -->
          <ul class="text-left list-none text-xs text-stone-600 ">
            <li class="mt-1"><b>Students: </b>{{$project->students_name}}</li>
            <li class="mt-1"><b>Supervisor: </b>{{$project->supervisor_name}}</li>
            <li class="mt-1"><b>Research Specialization: </b>{{$project->research_specialization}}</li>
            <li class="mt-1"><b>Upload Date: </b>{{ \Carbon\Carbon::parse($project->uploade_date)->format('d/m/Y')}}</li>
          </ul><!-- End Category List -->
        </div><!-- End  -->


      </div>


    </div>
  

<div>
  </div>

  </div>

  </div> 

  <script>
    var scrollpos = window.scrollY;
    var header = document.getElementById("header");
    var navcontent = document.getElementById("nav-content");
    var navaction = document.getElementById("navAction");
    var brandname = document.getElementById("brandname");
    var toToggle = document.querySelectorAll(".toggleColour");

    document.addEventListener("scroll", function() {
      /*Apply classes for slide in bar*/
      scrollpos = window.scrollY;

      if (scrollpos > 10) {
        header.classList.add("bg-[#F0F3F4] ");
        navaction.classList.remove("bg-[#F0F3F4] ");
        navaction.classList.add("gradient");
        navaction.classList.remove("text-gray-800");
        navaction.classList.add("text-white");
        //Use to switch toggleColour colours
        for (var i = 0; i < toToggle.length; i++) {
          toToggle[i].classList.add("text-gray-800");
          toToggle[i].classList.remove("text-white");
        }
        header.classList.add("shadow");
        navcontent.classList.remove("bg-gray-100");
        navcontent.classList.add("bg-[#F0F3F4] ");
      } else {
        header.classList.remove("bg-[#F0F3F4] ");
        navaction.classList.remove("gradient");
        navaction.classList.add("bg-[#F0F3F4] ");
        navaction.classList.remove("text-white");
        navaction.classList.add("text-gray-800");
        //Use to switch toggleColour colours
        for (var i = 0; i < toToggle.length; i++) {
          toToggle[i].classList.add("text-white");
          toToggle[i].classList.remove("text-gray-800");
        }

        header.classList.remove("shadow");
        navcontent.classList.remove("bg-[#F0F3F4] ");
        navcontent.classList.add("bg-gray-100");
      }
    });
  </script>
  <script>
    /*Toggle dropdown list*/
    /*https://gist.github.com/slavapas/593e8e50cf4cc16ac972afcbad4f70c8*/

    var navMenuDiv = document.getElementById("nav-content");
    var navMenu = document.getElementById("nav-toggle");

    document.onclick = check;

    function check(e) {
      var target = (e && e.target) || (event && event.srcElement);

      //Nav Menu
      if (!checkParent(target, navMenuDiv)) {
        // click NOT on the menu
        if (checkParent(target, navMenu)) {
          // click on the link
          if (navMenuDiv.classList.contains("hidden")) {
            navMenuDiv.classList.remove("hidden");
          } else {
            navMenuDiv.classList.add("hidden");
          }
        } else {
          // click both outside link and outside menu, hide menu
          navMenuDiv.classList.add("hidden");
        }
      }
    }

    function checkParent(t, elm) {
      while (t.parentNode) {
        if (t == elm) {
          return true;
        }
        t = t.parentNode;
      }
      return false;
    }
  </script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/flowbite/1.8.1/flowbite.min.js"></script>


  <section>@include('includes.footer') </section>

</body><!-- End Body -->

</html>