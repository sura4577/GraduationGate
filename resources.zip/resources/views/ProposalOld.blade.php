<!DOCTYPE html>
<html lang="en" class=" " >
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <meta http-equiv="X-UA-Compatible" content="ie=edge" />
        <title>Graduation Gate</title>
        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Varela+Round&display=swap" rel="stylesheet">
        <!-- Css Files -->
        <link rel="stylesheet" href="css/font-awesome.min.css" />
        <link rel="stylesheet" href="output.css" />
        <link rel="stylesheet" href="https://unpkg.com/tailwindcss@2.2.19/dist/tailwind.min.css"/>
    <!--Replace with your tailwind.css once created-->
    <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:400,700" rel="stylesheet" />
    <!-- Define your gradient here - use online tools to find a gradient matching your branding-->
        <script src="https://cdn.tailwindcss.com"></script>
        <style>
      .gradient {
        background: linear-gradient(30deg, #005299 0%, #0891B2 100%);
      }
    </style>

    </head><!-- End Head -->
    <body  class=" leading-normal tracking-normal bg-[#F0F3F4] " >
         <!--Nav-->
         @include('includes.header')
    <script>
      var scrollpos = window.scrollY;
      var header = document.getElementById("header");
      var navcontent = document.getElementById("nav-content");
      var navaction = document.getElementById("navAction");
      var brandname = document.getElementById("brandname");
      var toToggle = document.querySelectorAll(".toggleColour");

      document.addEventListener("scroll", function () {
        /*Apply classes for slide in bar*/
        scrollpos = window.scrollY;

        if (scrollpos > 10) {
          header.classList.add("bg-[#F0F3F4] ");
          navaction.classList.remove("bg-[#F0F3F4] ");
          navaction.classList.add("gradient");
          navaction.classList.remove("text-gray-800");
          navaction.classList.add("text-white");
          //Use to switch toggleColour colours
          for (var i = 0; i < toToggle.length; i++) {
            toToggle[i].classList.add("text-gray-800");
            toToggle[i].classList.remove("text-white");
          }
          header.classList.add("shadow");
          navcontent.classList.remove("bg-gray-100");
          navcontent.classList.add("bg-[#F0F3F4] ");
        } else {
          header.classList.remove("bg-[#F0F3F4] ");
          navaction.classList.remove("gradient");
          navaction.classList.add("bg-[#F0F3F4] ");
          navaction.classList.remove("text-white");
          navaction.classList.add("text-gray-800");
          //Use to switch toggleColour colours
          for (var i = 0; i < toToggle.length; i++) {
            toToggle[i].classList.add("text-white");
            toToggle[i].classList.remove("text-gray-800");
          }

          header.classList.remove("shadow");
          navcontent.classList.remove("bg-[#F0F3F4] ");
          navcontent.classList.add("bg-gray-100");
        }
      });
    </script>
    <script>
      /*Toggle dropdown list*/
      /*https://gist.github.com/slavapas/593e8e50cf4cc16ac972afcbad4f70c8*/

      var navMenuDiv = document.getElementById("nav-content");
      var navMenu = document.getElementById("nav-toggle");

      document.onclick = check;
      function check(e) {
        var target = (e && e.target) || (event && event.srcElement);

        //Nav Menu
        if (!checkParent(target, navMenuDiv)) {
          // click NOT on the menu
          if (checkParent(target, navMenu)) {
            // click on the link
            if (navMenuDiv.classList.contains("hidden")) {
              navMenuDiv.classList.remove("hidden");
            } else {
              navMenuDiv.classList.add("hidden");
            }
          } else {
            // click both outside link and outside menu, hide menu
            navMenuDiv.classList.add("hidden");
          }
        }
      }
      function checkParent(t, elm) {
        while (t.parentNode) {
          if (t == elm) {
            return true;
          }
          t = t.parentNode;
        }
        return false;
      }
    </script>
<nav class="flex mx-3 mt-2 pb-3 border-b-2  border-stone-300 " aria-label="Breadcrumb">
  <ol class="inline-flex items-center space-x-1 md:space-x-3">
    <li class="inline-flex items-center">
      <a href="Home.html" class="inline-flex items-center text-sm font-medium text-gray-700 "> 
        Home
      </a>
    </li>
    <li aria-current="page">
      <div class="flex items-center">
        <svg class="w-3 h-3 text-gray-400 mx-1" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 6 10">
          <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m1 9 4-4-4-4"/>
        </svg>
        <span class="ml-1 text-sm font-medium text-gray-500 md:ml-2 ">Projects</span>
      </div>
    </li>
  </ol>
</nav>




    <div class="flex md:w-full flex-wrap items-center  justify-center text-sm ">
      <div class="w-full justify-center flex my-3 mx-auto ">        
        <form>
            <div class="flex md:w-full">
                <label for="search-dropdown" class="mb-2 text-sm font-medium text-gray-900 sr-only ">Your Email</label>
                <button id="dropdown-button" data-dropdown-toggle="dropdown" class="flex-shrink-0 z-10 inline-flex items-center py-2.5 px-4 text-sm font-medium text-center text-gray-900 bg-gray-100 border border-gray-300 rounded-l-lg hover:bg-gray-200 " type="button"> All classifications <svg class="w-2.5 h-2.5 ml-2.5" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 10 6">
            <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m1 1 4 4 4-4"/>
          </svg></button>
                <div id="dropdown" class="z-10 hidden bg-white divide-y divide-gray-100 rounded-lg shadow w-96  ">
                    <ul class="py-2 px-4 text-sm text-gray-700 " aria-labelledby="dropdown-button">
                    <li>
                        <button type="button" class="inline-flex w-full px-10  py-2 hover:bg-gray-100 ">Information Technology</button>
                    </li>
                    <li>
                        <button type="button" class="inline-flex w-full px-10  py-2 hover:bg-gray-100 ">Computer Science</button>
                    </li>
                    <li>
                        <button type="button" class="inline-flex w-full px-10  py-2 hover:bg-gray-100 ">Artificial intelligence</button>
                    </li>
                    <li>
                        <button type="button" class="inline-flex w-full px-10  py-2 hover:bg-gray-100 ">Machine learning</button>
                    </li>
                    <li>
                        <button type="button" class="inline-flex w-full px-10  py-2 hover:bg-gray-100 ">Cyber security</button>
                    </li>
                    </ul>
                </div>
                <label for="search-dropdown" class="mb-2 text-sm font-medium text-gray-900 sr-only ">Your Email</label>
                <button id="dropdown-button" data-dropdown-toggle="dropdown" class="flex-shrink-0 z-10 inline-flex items-center py-2.5 px-4 text-sm font-medium text-center text-gray-900 bg-gray-100 border border-gray-300  hover:bg-gray-200 " type="button"> All years <svg class="w-2.5 h-2.5 ml-2.5" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 10 6">
            <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m1 1 4 4 4-4"/>
          </svg></button>
                <div id="dropdown" class="z-10 hidden bg-white divide-y divide-gray-100 rounded-lg shadow w-96  ">
                    <ul class="py-2 px-4 text-sm text-gray-700 " aria-labelledby="dropdown-button">
                    <li>
                        <button type="button" class="inline-flex w-full px-10  py-2 hover:bg-gray-100 ">2023</button>
                    </li>
                    <li>
                        <button type="button" class="inline-flex w-full px-10  py-2 hover:bg-gray-100 ">2022</button>
                    </li>
                    <li>
                        <button type="button" class="inline-flex w-full px-10  py-2 hover:bg-gray-100 ">2021</button>
                    </li>
                    <li>
                        <button type="button" class="inline-flex w-full px-10  py-2 hover:bg-gray-100 ">2020</button>
                    </li>
                    <li>
                        <button type="button" class="inline-flex w-full px-10  py-2 hover:bg-gray-100 ">2019</button>
                    </li>
                    </ul>
                </div>
                
                <div class="relative w-full ">
                    <input type="search" id="search-dropdown" class="block p-2.5 pr-24  md:pr-96   w-full  text-sm text-gray-900 bg-gray-50 rounded-r-lg border-l-gray-50 border-l-2 border border-gray-300 px-100" placeholder="Search .." required>
                    <button type="submit" class="absolute top-0 right-0 p-2.5 text-sm font-medium h-full text-white bg-cyan-600 rounded-r-lg border border-cyan-600  ">
                        <svg class="w-900 h-4" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 20 20">
                            <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m19 19-4-4m0-7A7 7 0 1 1 1 8a7 7 0 0 1 14 0Z"/>
                        </svg>
                        <span class="sr-only ">Search</span>
                    </button>
                </div>
            </div>
        </form>
      </div>
    

   </div>

 


    <div class=" flex flex-wrap justify-center text-center text-sm md:w-full w-11/12 mx-auto ">
      
   <div  class=" w-full md:w-10/12 flex items-center">
              <div class="w-8/12 md:w-10/12 ">
                <h1 class="text-left text-xl  md:ml-8"> Projects :</h1> 
              </div>
                  <div class="justify-center p-1 mx-1 ">
                    <a href="UploadProjects.html">
                        <button  class="w-full md:w-10/12 p-1 gradientgradient border-0 rounded-sm mx-2 md:mx-4 items-center hover:bg-cyan-600 hover:cursor-pointer"><i class="fa fa-upload text-white text-xs" aria-hidden="true"> Upload Projects</i></button></a>
                </div>
              </div>

<!-- Card -->
<div class="md:max-w-xs p-6 bg-white border border-gray-200 rounded-lg shadow m-2 hover:bg-opacity-50">
      <h5 class="mb-2 text-lg md:text-2xl font-bold tracking-tight text-gray-900 ">Title</h5>
  <p class="mb-3 font-normal text-gray-700  text-left ">The specialty of this project is the <b>research specialty</b> In this project, it was supervised by the <b>supervisor’s name</b> and worked on by the <b>student’s name </b> , <b>student’s name </b>and <b>student’s name </b></p>
  <div class="w-full flex flex-wrap items-center border-t-2 border-black-100 border-solid">
  <a href="Abstract.html" class="float-left  px-3 py-2 text-sm font-medium text-center text-white gradientgradient rounded-lg  hover:bg-cyan-600 mt-2 ">
      Read more ..
  </a>
  <p class="float-right text-stone-600 mt-2  text-xs text-end md:ml-20 ml-52 " ><b>9/24/2020</b></p>
  </div>
</div>

<!-- Card -->
<div class="md:max-w-xs p-6 bg-white border border-gray-200 rounded-lg shadow m-2 hover:bg-opacity-50">
      <h5 class="mb-2 text-lg md:text-2xl font-bold tracking-tight text-gray-900 ">Title</h5>
  <p class="mb-3 font-normal text-gray-700  text-left ">The specialty of this project is the <b>research specialty</b> In this project, it was supervised by the <b>supervisor’s name</b> and worked on by the <b>student’s name </b> , <b>student’s name </b>and <b>student’s name </b></p>
  <div class="w-full flex flex-wrap items-center border-t-2 border-black-100 border-solid">
  <a href="Abstract.html" class="float-left  px-3 py-2 text-sm font-medium text-center text-white gradientgradient rounded-lg  hover:bg-cyan-600 mt-2 ">
      Read more ..
  </a>
  <p class="float-right text-stone-600 mt-2  text-xs text-end md:ml-20 ml-52 " ><b>9/24/2020</b></p>
  </div>
</div>

<!-- Card -->
<div class="md:max-w-xs p-6 bg-white border border-gray-200 rounded-lg shadow m-2 hover:bg-opacity-50">
      <h5 class="mb-2 text-lg md:text-2xl font-bold tracking-tight text-gray-900 ">Title</h5>
  <p class="mb-3 font-normal text-gray-700  text-left ">The specialty of this project is the <b>research specialty</b> In this project, it was supervised by the <b>supervisor’s name</b> and worked on by the <b>student’s name </b> , <b>student’s name </b>and <b>student’s name </b></p>
  <div class="w-full flex flex-wrap items-center border-t-2 border-black-100 border-solid">
  <a href="Abstract.html" class="float-left  px-3 py-2 text-sm font-medium text-center text-white gradientgradient rounded-lg  hover:bg-cyan-600 mt-2 ">
      Read more ..
  </a>
  <p class="float-right text-stone-600 mt-2  text-xs text-end md:ml-20 ml-52 " ><b>9/24/2020</b></p>
  </div>
</div>

<!-- Card -->
<div class="md:max-w-xs p-6 bg-white border border-gray-200 rounded-lg shadow m-2 hover:bg-opacity-50">
      <h5 class="mb-2 text-lg md:text-2xl font-bold tracking-tight text-gray-900 ">Title</h5>
  <p class="mb-3 font-normal text-gray-700  text-left ">The specialty of this project is the <b>research specialty</b> In this project, it was supervised by the <b>supervisor’s name</b> and worked on by the <b>student’s name </b> , <b>student’s name </b>and <b>student’s name </b></p>
  <div class="w-full flex flex-wrap items-center border-t-2 border-black-100 border-solid">
  <a href="Abstract.html" class="float-left  px-3 py-2 text-sm font-medium text-center text-white gradientgradient rounded-lg  hover:bg-cyan-600 mt-2 ">
      Read more ..
  </a>
  <p class="float-right text-stone-600 mt-2  text-xs text-end md:ml-20 ml-52 " ><b>9/24/2020</b></p>
  </div>
</div>

<!-- Card -->
<div class="md:max-w-xs p-6 bg-white border border-gray-200 rounded-lg shadow m-2 hover:bg-opacity-50">
      <h5 class="mb-2 text-lg md:text-2xl font-bold tracking-tight text-gray-900 ">Title</h5>
  <p class="mb-3 font-normal text-gray-700  text-left ">The specialty of this project is the <b>research specialty</b> In this project, it was supervised by the <b>supervisor’s name</b> and worked on by the <b>student’s name </b> , <b>student’s name </b>and <b>student’s name </b></p>
  <div class="w-full flex flex-wrap items-center border-t-2 border-black-100 border-solid">
  <a href="Abstract.html" class="float-left  px-3 py-2 text-sm font-medium text-center text-white gradientgradient rounded-lg  hover:bg-cyan-600 mt-2 ">
      Read more ..
  </a>
  <p class="float-right text-stone-600 mt-2  text-xs text-end md:ml-20 ml-52 " ><b>9/24/2020</b></p>
  </div>
</div>

<!-- Card -->
<div class="md:max-w-xs p-6 bg-white border border-gray-200 rounded-lg shadow m-2 hover:bg-opacity-50">
      <h5 class="mb-2 text-lg md:text-2xl font-bold tracking-tight text-gray-900 ">Title</h5>
  <p class="mb-3 font-normal text-gray-700  text-left ">The specialty of this project is the <b>research specialty</b> In this project, it was supervised by the <b>supervisor’s name</b> and worked on by the <b>student’s name </b> , <b>student’s name </b>and <b>student’s name </b></p>
  <div class="w-full flex flex-wrap items-center border-t-2 border-black-100 border-solid">
  <a href="Abstract.html" class="float-left  px-3 py-2 text-sm font-medium text-center text-white gradientgradient rounded-lg  hover:bg-cyan-600 mt-2 ">
      Read more ..
  </a>
  <p class="float-right text-stone-600 mt-2  text-xs text-end md:ml-20 ml-52 " ><b>9/24/2020</b></p>
  </div>
</div>

<!-- Card -->
<div class="md:max-w-xs p-6 bg-white border border-gray-200 rounded-lg shadow m-2 hover:bg-opacity-50">
      <h5 class="mb-2 text-lg md:text-2xl font-bold tracking-tight text-gray-900 ">Title</h5>
  <p class="mb-3 font-normal text-gray-700  text-left ">The specialty of this project is the <b>research specialty</b> In this project, it was supervised by the <b>supervisor’s name</b> and worked on by the <b>student’s name </b> , <b>student’s name </b>and <b>student’s name </b></p>
  <div class="w-full flex flex-wrap items-center border-t-2 border-black-100 border-solid">
  <a href="Abstract.html" class="float-left  px-3 py-2 text-sm font-medium text-center text-white gradientgradient rounded-lg  hover:bg-cyan-600 mt-2 ">
      Read more ..
  </a>
  <p class="float-right text-stone-600 mt-2  text-xs text-end md:ml-20 ml-52 " ><b>9/24/2020</b></p>
  </div>
</div>

<!-- Card -->
<div class="md:max-w-xs p-6 bg-white border border-gray-200 rounded-lg shadow m-2 hover:bg-opacity-50">
      <h5 class="mb-2 text-lg md:text-2xl font-bold tracking-tight text-gray-900 ">Title</h5>
  <p class="mb-3 font-normal text-gray-700  text-left ">The specialty of this project is the <b>research specialty</b> In this project, it was supervised by the <b>supervisor’s name</b> and worked on by the <b>student’s name </b> , <b>student’s name </b>and <b>student’s name </b></p>
  <div class="w-full flex flex-wrap items-center border-t-2 border-black-100 border-solid">
  <a href="Abstract.html" class="float-left  px-3 py-2 text-sm font-medium text-center text-white gradientgradient rounded-lg  hover:bg-cyan-600 mt-2 ">
      Read more ..
  </a>
  <p class="float-right text-stone-600 mt-2  text-xs text-end md:ml-20 ml-52 " ><b>9/24/2020</b></p>
  </div>
</div>

<!-- Card -->
<div class="md:max-w-xs p-6 bg-white border border-gray-200 rounded-lg shadow m-2 hover:bg-opacity-50">
      <h5 class="mb-2 text-lg md:text-2xl font-bold tracking-tight text-gray-900 ">Title</h5>
  <p class="mb-3 font-normal text-gray-700  text-left ">The specialty of this project is the <b>research specialty</b> In this project, it was supervised by the <b>supervisor’s name</b> and worked on by the <b>student’s name </b> , <b>student’s name </b>and <b>student’s name </b></p>
  <div class="w-full flex flex-wrap items-center border-t-2 border-black-100 border-solid">
  <a href="Abstract.html" class="float-left  px-3 py-2 text-sm font-medium text-center text-white gradientgradient rounded-lg  hover:bg-cyan-600 mt-2 ">
      Read more ..
  </a>
  <p class="float-right text-stone-600 mt-2  text-xs text-end md:ml-20 ml-52 " ><b>9/24/2020</b></p>
  </div>
</div>


<br>
<div class="flex items-center justify-between  px-4 py-3 sm:px-6">
  <div class="flex flex-1 justify-between sm:hidden">
    <a href="#" class="relative inline-flex items-center rounded-md border border-gray-300 bg-white px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50"><i class="fa fa-angle-left" aria-hidden="true"></i></a>
    <a href="#" class="relative ml-3 inline-flex items-center rounded-md border border-gray-300 bg-white px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50 "><i class="fa fa-angle-right" aria-hidden="true"></i> </a>
  </div>
  <div class="hidden sm:flex sm:flex-1 sm:items-center sm:justify-between">
    <div>
      <nav class="isolate inline-flex -space-x-px rounded-md shadow-sm" aria-label="Pagination">
        <a href="#" class="relative inline-flex items-center rounded-l-md px-2 py-2 text-gray-400 ring-1 ring-inset ring-gray-300 hover:bg-gray-50 focus:z-20 ">
          <span class="sr-only">Previous</span>
          <svg class="h-5 w-5" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
            <path fill-rule="evenodd" d="M12.79 5.23a.75.75 0 01-.02 1.06L8.832 10l3.938 3.71a.75.75 0 11-1.04 1.08l-4.5-4.25a.75.75 0 010-1.08l4.5-4.25a.75.75 0 011.06.02z" clip-rule="evenodd" />
          </svg>
        </a>
        <!-- Current: "z-10 bg-indigo-600 text-white focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600", Default: "text-gray-900 ring-1 ring-inset ring-gray-300 hover:bg-gray-50 focus:outline-offset-0" -->
        <a href="#" aria-current="page" class="relative z-10 inline-flex items-center gradientgradient px-4 py-2 text-sm font-semibold text-white ">1</a>
        <a href="#" class="relative inline-flex items-center px-4 py-2 text-sm font-semibold text-gray-900 ring-1 ring-inset ring-gray-300 hover:bg-gray-50 ">2</a>
        <a href="#" class="relative hidden items-center px-4 py-2 text-sm font-semibold text-gray-900 ring-1 ring-inset ring-gray-300 hover:bg-gray-50  md:inline-flex">3</a>
        <span class="relative inline-flex items-center px-4 py-2 text-sm font-semibold text-gray-700 ring-1 ring-inset ring-gray-300 ">...</span>
        <a href="#" class="relative hidden items-center px-4 py-2 text-sm font-semibold text-gray-900 ring-1 ring-inset ring-gray-300 hover:bg-gray-50  md:inline-flex">8</a>
        <a href="#" class="relative inline-flex items-center px-4 py-2 text-sm font-semibold text-gray-900 ring-1 ring-inset ring-gray-300 hover:bg-gray-50 ">9</a>
        <a href="#" class="relative inline-flex items-center px-4 py-2 text-sm font-semibold text-gray-900 ring-1 ring-inset ring-gray-300 hover:bg-gray-50 ">10</a>
        <a href="#" class="relative inline-flex items-center rounded-r-md px-2 py-2 text-gray-400 ring-1 ring-inset ring-gray-300 hover:bg-gray-50 ">
          <span class="sr-only">Next</span>
          <svg class="h-5 w-5" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
            <path fill-rule="evenodd" d="M7.21 14.77a.75.75 0 01.02-1.06L11.168 10 7.23 6.29a.75.75 0 111.04-1.08l4.5 4.25a.75.75 0 010 1.08l-4.5 4.25a.75.75 0 01-1.06-.02z" clip-rule="evenodd" />
          </svg>
        </a>
      </nav>
    </div>
  </div>
</div>






    </div>
    


  </container>
</body>
</html>
