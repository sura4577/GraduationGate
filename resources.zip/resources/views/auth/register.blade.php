
@include('includes.head')
<body  class=" leading-normal tracking-normal bg-[#F0F3F4] min-h-screen flex flex-col" >
         <!--Nav-->
         @include('includes.header')
         
            
 <section> 
 <nav class="flex mb-4 mx-3 my-2" aria-label="Breadcrumb">
  <ol class="inline-flex items-center space-x-1 md:space-x-3">
    <li class="inline-flex items-center">
      <a href="Home.html" class="inline-flex items-center text-sm font-medium text-cyan-950  underline  "> 
        Home
      </a>
    </li>
    <li aria-current="page">
      <div class="flex items-center">
        <svg class="w-3 h-3 text-[#005299] mx-1" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 6 10">
          <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m1 9 4-4-4-4"/>
        </svg>
        <span class="ml-1 text-sm font-medium  text-[#0891B2] md:ml-2 ">Sign Up</span>
      </div>
    </li>
  </ol>
</nav>
  
<div class="content">
    <div class="container mx-auto">
        <div class="flex flex-col md:flex-row">
            <div class="w-11/12 md:w-5/12 lg:w-5/12 mx-auto">
                <div class="bg-white rounded shadow-lg p-6">

  <form method="POST" action="{{ route('register') }}">
    @csrf
    <h5 class="text-xl font-medium text-gray-900 mb-2 ">Sign Up</h5>
    <div class="mb-4">
        <label for="name" class="block text-gray-700 text-sm font-bold mb-2">{{ __('Your Name') }}</label>
        <input type="text" name="name"
               class="block p-2.5 w-full text-sm text-gray-900 bg-gray-50 rounded-lg border border-gray-300 form-input @error('name') border-red-500 @enderror"
               placeholder="{{ __('Name') }}" value="{{ old('name') }}" required autocomplete="name" autofocus>
        @error('name')
        <p class="text-red-500 text-xs italic">{{ $message }}</p>
        @enderror
    </div>

    <div class="mb-4">
        <label for="email" class="block text-gray-700 text-sm font-bold mb-2">{{ __('Your Email') }}</label>
        <input type="email" name="email"
               class="block p-2.5 w-full text-sm text-gray-900 bg-gray-50 rounded-lg border border-gray-300 form-input @error('email') border-red-500 @enderror"
               placeholder="name@company.com" value="{{ old('email') }}" required autocomplete="email">
        @error('email')
        <p class="text-red-500 text-xs italic">{{ $message }}</p>
        @enderror
    </div>

    <div class="mb-4">
        <label for="password" class="block text-gray-700 text-sm font-bold mb-2">{{ __('Your Password') }}</label>
        <input type="password" name="password"
               class="block p-2.5 w-full text-sm text-gray-900 bg-gray-50 rounded-lg border border-gray-300 form-input @error('password') border-red-500 @enderror"
               placeholder="••••••••" required autocomplete="new-password">
        @error('password')
        <p class="text-red-500 text-xs italic">{{ $message }}</p>
        @enderror
    </div>

    <div class="mb-4">
        <label for="password_confirmation" class="block text-gray-700 text-sm font-bold mb-2">{{ __('Confirm Password') }}</label>
        <input type="password" name="password_confirmation"
               class="block p-2.5 w-full text-sm text-gray-900 bg-gray-50 rounded-lg border border-gray-300 form-input @error('password_confirmation') border-red-500 @enderror"
               placeholder="••••••••" required autocomplete="new-password">
        @error('password_confirmation')
        <p class="text-red-500 text-xs italic">{{ $message }}</p>
        @enderror
    </div>

    <div class="text-center md:text-right mt-6">
        <button type="submit" class="w-full text-white bg-cyan-950 hover:bg-cyan-600 focus:ring-4 focus:outline-none focus:ring-cyan-600 font-medium rounded-lg text-sm px-5 py-2.5 text-center mt-2">
            {{ __('Sign Up') }}
        </button>
    </div>
</form>

</div>
            </div>
        </div>
        <!-- /.flex -->
    </div>
    <!-- /.container-fluid -->
</div>
<!-- /.content -->

</section>


@include('includes.footer')

</body>
</html>

