@extends('admin.layouts.app')

@section('content')
    <!-- Content Header (Page header) -->
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0">{{ __('Edit Project') }}</h1>
                    
                </div><!-- /.col -->
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="my-10 mx-auto w-11/12 md:w-full  p-3  bg-white rounded-md  text-sm">


<form action="{{ url('editGroup') }}" method="post" enctype="multipart/form-data">
    @csrf
    <div class="block md:flex md:flex-wrap py-2 px-4 md:px-4 justify-center">
        <div class="justify-center items-center w-full p-b-1 my-1 mx-auto">
            <!-- Group Number Input -->
            <label class="w-full text-cyan-950 text-md m-1">Group No</label>
            <input class="block p-2.5 w-full text-sm text-gray-900 bg-gray-50 rounded-lg border border-gray-300" 
            type="text" name="editGroupNo" value="{{ $group->group_number }}">
            
            <!-- Student Name Input -->
            <label class="w-full text-cyan-950 text-md m-1">Student Name</label>
            <textarea class="block p-2.5 w-full text-sm text-gray-900 bg-gray-50 rounded-lg border border-gray-300" 
            name="editGroupStName">{{ $group->students_name }}</textarea>
            
            <!-- Priority List Name Input -->
            <label class="w-full text-cyan-950 text-md m-1">Priority List Name</label>
            <textarea class="block p-2.5 w-full text-sm text-gray-900 bg-gray-50 rounded-lg border border-gray-300" 
            name="editGroupPrList">{{ $group->priorities_list }}</textarea>
            
            <!-- Hidden Input for Group ID -->
            <input type="hidden" name="editGroupId" value="{{ $group->id }}">
        </div>
    </div>

    <!-- Save changes -->
<div class="text-center overflow-hidden w-full my-3 mx-auto text-md rounded-sm text-white">
<button 
class="w-10/12 md:w-2/12 my-2 p-1 text-md rounded-sm text-white bg-cyan-950 hover:bg-stone-300 hover:text-cyan-950 md:float-right mr-6 md:mr-4">
        Save</button>
    </div>
</form>




                        </div>
                    </div>
                </div>
            </div>
            <!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content -->
    <script>
        function addRow(val_this){
            $('.documentCol').append($('.documentRow:first').clone())
            $('.documentRow:last').find('.editprojectFile').val('');
            
        }
        function removeRow(val_this){
           $(val_this).parent().parent('div').remove();
        }
    </script>
@endsection 