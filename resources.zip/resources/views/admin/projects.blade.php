@extends('admin.layouts.app')

@section('content')
    <!-- Content Header (Page header) -->
    <div class="contentheader">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0">{{ __(' Projects') }}</h1>
                </div>
                <div class="col-sm-6">
                    <a class="btn btn-primary btn-lg float-right" href="{{ route('addProjects') }}">Add Projects</a>
                </div>
            </div>
            
        </div>
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        @if(Session::has('success'))
                            <div class="alert alert-success alert-dismissible show">
                                {{ session('success') }}
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                        @endif
                        @if(Session::has('error'))
                            <div class="alert alert-danger alert-dismissible show">
                                {{ session('error') }}
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                        @endif
                        <div class="card-body">
                            <table class="table" style="width:100%;">
                                <thead>
                                    <tr>
                                        <th style="width:5%">Sr</th>
                                        <th style="width:25%">Name</th>
                                        <th style="width:30%">Files</th>
                                        <th style="width:25%">Abstract</th>
                                        <th style="width:15%">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach($projects as $project)
                                        <tr>
                                           <td>{{$loop->iteration}}</td>
                                           <td>{{$project->name}}</td>
                                           <td>
                                                @php
                                                    $projectFiles = DB::table('project_files')->where('project_id', intval($project->id))->get();
                                                @endphp
                                                @foreach ($projectFiles as $projectFile)
                                                    <a href="{{ URL::to('/') }}/uploades/{{ $projectFile->file }}"> 
                                                        @php
                                                            $ext = pathinfo($projectFile->file ,PATHINFO_EXTENSION);
                                                            if($ext == 'pdf'){
                                                        @endphp
                                                            <img style="width:50px;height:50px" src="{{ URL::to('/') }}/images/dummyFile.png" alt="">
                                                        @php }else{ @endphp
                                                            <img style="width:50px;height:50px" src="{{ URL::to('/') }}/uploades/{{ $projectFile->file }}" alt="">
                                                        @php } @endphp
                                                    </a>   
                                                @endforeach
                                           </td>
                                           <td>{{$project->narration}}</td> 
                                           <td>
                                                <a href="{{ route('showProject',['id'=>$project->id]) }}" class="btn btn-primary">Edit</a>
                                                <a onclick="return confirm('Are You Sure To Delete')" href="{{ route('delProjects',['id'=>$project->id]) }}" class="btn btn-danger">Delete</a>
                                           </td> 
                                        </tr>
                                    @endforeach
                                </tbody>
                            </table>
                            {{$projects}}
                        </div>
                    </div>
                </div>
            </div>
            <!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content -->
@endsection