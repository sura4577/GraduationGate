@extends('admin.layouts.app')

@section('content')

    <!-- Content Header (Page header) -->
<div class=" flex shadow-md sm:rounded-lg border-t-2 border-stone-300 text-sm">
  <div  class="w-full flex items-center ">
    <div class="w-5/12 md:w-9/12  p-2 flex items:center mb-2">
      <h1 class="text-left md:text-xl text-lg  "> {{ __('Proposals') }} </h1> 
    </div>

    <div class="w-3/12 md:w-2/12 justify-center m-1 md:m-0">
      <a href="{{ url('/proposals') }}">
        <button  class="w-full md:w-11/12  md:px-1 py-2  border-0 rounded-sm mx-2 md:mx-1 items-center gradient  hover:bg-cyan-600 hover:cursor-pointer text-white text-xs ">Browse Proposal</button></a>
    </div>

    <div class="w-3/12 md:w-2/12 justify-center md:mr-6">
      <a href="{{url('/UploadProposal')}}">
        <button  class="w-full md:w-11/12  md:px-1 py-2  border-0 rounded-sm mx-2 md:mx-1 items-center gradient  hover:bg-cyan-600 hover:cursor-pointer text-white text-xs "><i class="fa fa-plus text-white  px-1 " aria-hidden="true"></i>Upload Proposal</button></a>
    </div>
  </div>
</div>
    <!-- /.content-header -->

    <!-- Main content -->
    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        @if(Session::has('success'))
                            <div class="alert alert-success alert-dismissible show">
                                {{ session('success') }}
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                        @endif
                        @if(Session::has('error'))
                            <div class="alert alert-danger alert-dismissible show">
                                {{ session('error') }}
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                        @endif

                        <div class="overflow-auto rounded-lg shadow hidden md:block md:mx-2 text-sm">
                            <table class="table bg-gray-50 w-full" >
                                <thead class="bg-gray-50 border-b-2 border-gray-200">
                                    <tr>
                                        <th class="w-1/12 text-sm font-semibold tracking-wide text-center">Sr</th>
                                        <th class="w-1/12 text-sm font-semibold tracking-wide text-center">Title</th>
                                        <th class="w-1/12 text-sm font-semibold tracking-wide text-center">Superviser</th>
                                        <th class="w-1/12 text-sm font-semibold tracking-wide text-center">Speciealization</th>
                                        <th class="w-8/12 text-sm font-semibold tracking-wide text-center">Proposal</th>
                                        <th class="w-2/12 text-sm font-semibold tracking-wide text-center">Action</th>
                                    </tr>
                                </thead>
                                <tbody class="divide-y divide-gray-100">
                                    @foreach($proposals as $proposal)
                                        <tr class="bg-white">
                                           <td class="p-3 text-sm text-gray-700 whitespace-nowrap text-center">{{$loop->iteration}}</td>
                                           <td class="p-3 text-sm text-gray-700 whitespace-wrap text-center">{{$proposal->title}}</td>
                                           <td class="p-3 text-sm text-gray-700 whitespace-wrap text-center">{{$proposal->supervisor_name}}</td>
                                           <td class="p-3 text-sm text-gray-700 whitespace-nowrap text-center">{{$proposal->research_specialization}}</td> 
                                           <td class="p-3 text-sm text-gray-700 whitespace-wrap ">{{$proposal->proposal}}</td> 
                                           <td  class="flex flex-warp justfiy-center items-centter">
                                                <a onclick="return confirm('Do You Want To approve Proposal')" href="{{ route('approveProposal',['id'=>$proposal->id]) }}"class="btn btn-primary p-2 m-1 border-0 rounded-sm  bg-stone-200 hover:bg-cyan-950  hover:opacity-3 text-green-600">Approve</a>
                                                <a onclick="return confirm('Do You Want To Reject Proposal')" href="{{ route('rejectProposal',['id'=>$proposal->id]) }}"class="btn btn-danger p-2 m-1 border-0 rounded-sm  bg-stone-200 hover:bg-cyan-950  hover:opacity-3 text-red-600">Reject</a>
                                           </td> 
                                        </tr>
                                    @endforeach
                                </tbody>
                            </table>
                            {{$proposals}}
                        </div>
                        <!--in smail screen --> 
              <div class="grid grid-cols-1 sm:grid-cols-2 gap-4 md:hidden ">
              @foreach($proposals as $proposal)
                <div class="bg-white space-y-3 p-4 rounded-lg shadow ">
                  <div class="w-full flex items-center space-x-2 text-sm">
                    <div class="w-6/12 ">
                      <a href="#" class="text-cyan-950 font-bold ">{{$proposal->title}}</a>
                    </div>
                    <div class="w-6/12 text-gray-500">{{$proposal->supervisor_name}}</div>
                  </div>
                  <div class="text-sm text-gray-700">
                  {{$proposal->research_specialization}}                  </div>
                  <div class="text-sm text-gray-700 border-b-2 border-gray-200 pb-2">
                  {{$proposal->proposal}}
                  </div>
                  <div cliss="w-full flex flex-warp float-right ">
                    <a onclick="return confirm('Do You Want To approve Proposal')" href="{{ route('approveProposal',['id'=>$proposal->id]) }}"class="btn btn-primary p-2 m-1 border-0 rounded-sm  bg-stone-200 hover:bg-cyan-950  hover:opacity-3 text-green-600 float-right text-sm ">Approve</a>
                    <a onclick="return confirm('Do You Want To Reject Proposal')" href="{{ route('rejectProposal',['id'=>$proposal->id]) }}"class="btn btn-danger p-2 m-1 border-0 rounded-sm  bg-stone-200 hover:bg-cyan-950  hover:opacity-3 text-red-600 float-right text-sm">Reject</a>
                                          
                    </div>
                </div>
                @endforeach
                    </div>
                </div>
                {{$proposals}}
            </div>
            <!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content -->
@endsection