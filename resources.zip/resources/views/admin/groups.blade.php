@extends('admin.layouts.app')

@section('content')
<div id="print-indicator" class="fixed text-center top-10 left-10 right-0 bottom-0 bg-white bg-opacity-50 z-50 hidden print-hiddenml-24">
    <p class="text-red-600 font-bold p-4 border-b border-l border-r border-t-0 border-red-600 border-opacity-90 border-8 bg-black bg-opacity-70 text-center print-hidden ml-24">
        Please close the print page and then refresh the page.
    </p>
</div>


    <!-- Content Header (Page header) -->
    <div class=" flex  shadow-md sm:rounded-lg border-t-2 border-stone-300 text-sm">
  <div  class="w-full flex items-center ">
    <div class="w-10/12 md:w-11/12 p-2 flex items:center mb-2">
      <h1 class="text-left md:text-xl text-lg "> {{ __('Groups') }} </h1> 
    </div>
    <div class="w-2/12 md:w-1/12 justify-center p-1 md:w-xs print-hidden"> 
    <button onclick="openPrintPopup()" class="w-full p-1 md:px-3 py-2  border-0 rounded-sm mx-3 md:mx-1 items-center gradient  hover:bg-cyan-600 hover:cursor-pointer text-white text-xs print-hidden">
        <i class="fa fa-print text-white  px-1" aria-hidden="true"></i>Print
    </button>
</div>

    
    <div class="justify-center p-1 mr-3 md:w-xs ">
    
      <a href="{{ url('AddGroup') }}">
        <button  class="w-full p-1 md:px-3 py-2  border-0 rounded-sm mx-3 md:mx-1 items-center gradient  hover:bg-cyan-600 hover:cursor-pointer text-white text-xs "><i class="fa fa-plus text-white  px-1 " aria-hidden="true"></i>Add Group</button></a>
    </div>
  </div>
</div>
    <!-- /.content-header -->

    <!-- Main content -->
    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        @if(Session::has('success'))
                            <div class="alert alert-success alert-dismissible show">
                                {{ session('success') }}
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                        @endif
                        @if(Session::has('error'))
                            <div class="alert alert-danger alert-dismissible show">
                                {{ session('error') }}
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                        @endif
                        <div class="overflow-auto rounded-lg shadow hidden md:block md:mx-2 text-sm">
                        
                            <table class="table bg-gray-50 border-b-2 border-gray-200">
                                <thead class="bg-gray-50 border-b-2 border-gray-200">
                                    <tr>
                                        <!-- <th style="width:5%">Sr</th> -->
                                        <th class="w-1/12 text-sm font-semibold tracking-wide text-center">Group Number</th>
                                        <th class="w-2/12 text-sm font-semibold tracking-wide text-center ">Studentes Name</th>
                                        <th class="w-8/12 text-sm font-semibold tracking-wide text-center">Priorities List</th>
                                        <th class="w-2/12 text-sm font-semibold tracking-wide text-center print-hidden">Action</th>
                                        
                                    </tr>
                                </thead>
                                <tbody class="divide-y divide-gray-100">
                                    @foreach($groups as $group)
                                        <tr class="bg-white">
                                           <!-- <td>{{$loop->iteration}}</td> -->
                                           <td class="p-3 text-sm text-gray-700 whitespace-nowrap text-center">{{$loop->iteration}}</td>
                                           <td class="p-3 text-sm text-gray-700 whitespace-wrap text-center">{{$group->students_name}}</td>
                                           <td class="p-3 text-sm text-gray-700 whitespace-wrap ">{{$group->priorities_list}}</td>
                                           <td class="flex flex-warp justfiy-center items-centter print-hidden" >
                                                <a href="{{ route('showGroup',['id'=>$group->id]) }}"  class="btn btn-primary p-2 m-1 border-0 rounded-sm  bg-stone-200 hover:bg-cyan-950  hover:opacity-3  text-cyan-600">Edit</a>
                                                <a onclick="return confirm('Are You Sure To Delete')" href="{{ route('delGroup',['id'=>$group->id]) }}" class="btn btn-danger p-2 m-1 border-0 rounded-sm  bg-stone-200 hover:bg-cyan-950  hover:opacity-3"><i class="fa fa-trash text-red-600 hover:text-white" aria-hidden="true"></i></a>
                                           </td> 
                                        </tr>
                                    @endforeach

                                       
                                   
                                </tbody>
                             
                            </table>
                            
                            {{$groups}}
                         
                        </div>

                        <!--in smail screen --> 
              <div class="grid grid-cols-1 sm:grid-cols-2 gap-4 md:hidden">
              @foreach($groups as $group)
                <div class="bg-white space-y-3 p-4 rounded-lg shadow">
                            <div class="space-x-2 text-sm">
                                <p class="text-cyan-950 font-bold hover:underline">{{$loop->iteration}}</p>
                            </div>
                            <div class="text-sm text-gray-700 border-b-2 border-gray-200 pb-2">
                            {{$group->priorities_list}}
                            </div>
                            <div class="flex flex-wrap items-center w-full  "> 
                                <p class="w-8/12 text-sm font-medium text-black">{{$group->students_name}} </p>
                                <div class="w-4/12 flex flex-wrap items-centter float-right">
                                <a href="{{ route('showGroup',['id'=>$group->id]) }}"  class="btn btn-primary p-2 m-1 border-0 rounded-sm  bg-stone-200 hover:bg-cyan-950  hover:opacity-3  text-cyan-600">Edit</a>
                                <a onclick="return confirm('Are You Sure To Delete')" href="{{ route('delGroup',['id'=>$group->id]) }}" class="btn btn-danger p-2 m-1 border-0 rounded-sm  bg-stone-200 hover:bg-cyan-950  hover:opacity-3"><i class="fa fa-trash text-red-600 hover:text-white" aria-hidden="true"></i></a>
                                    </div>   
                            </div>
                </div>
                @endforeach
                
                    </div>

                </div>

            </div>
            <!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content -->
    <style>
        @media print {
            body * {
                visibility: hidden;
            }
            #print-content,
            #print-content * {
                visibility: visible;
            }
        }
    </style>

   <!-- ... Existing content ... -->

   <script>
    let printWindow;

    
    function openPrintPopup() {
    // Check if the print popup is already open
    if (printWindow && !printWindow.closed) {
        // If open, show the print indicator on the main page and return
        document.getElementById('print-indicator').style.display = 'block';
        return;
    }

    // Hide the print indicator
    document.getElementById('print-indicator').style.display = 'none';

    // Display the print indicator on the main page
    document.getElementById('print-indicator').style.display = 'block';

    // Open a new print popup
    printWindow = window.open('', '_blank');

    // Use onload event to ensure the content is loaded before printing
    printWindow.onload = function () {
        printWindow.document.write('<html><head><style>');
        
        // Include the Tailwind CSS styles directly in the print window
        printWindow.document.write(`
            /* Your Tailwind CSS styles here */
            body {
                font-family: 'your-preferred-font', sans-serif;
                /* Add other body styles as needed */
            }

            table {
                width: 100%;
                border-collapse: collapse;
                margin-bottom: 1rem;
            }

            th, td {
                padding: 0.75rem;
                text-align: left;
                border-bottom: 1px solid #e2e8f0;
            }

            th {
                background-color: #f7fafc;
            }

            .print-hidden {
                display: none;
            }

            /* Add more styles as needed for your specific table design */

        `);

        printWindow.document.write('</style></head><body>');

        printWindow.document.write('<div id="print-content" class="text-lg bg-gray-100 p-4">');
        printWindow.document.write(document.querySelector('.overflow-auto').outerHTML);
        printWindow.document.write('</div></body></html>');
        printWindow.document.close();
        printWindow.print();
    };
}

</script>



@endsection