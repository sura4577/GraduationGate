@extends('admin.layouts.app')

@section('content')
    <!-- Content Header (Page header) -->
    <div class=" flex shadow-md sm:rounded-lg border-t-2 border-stone-300 text-sm">
  <div  class="w-full flex items-center ">
    <div class="w-10/12 md:w-11/12 p-2 flex items:center mb-2">
      <h1 class="text-left md:text-xl text-lg"> {{ __('Upload Project') }} </h1> 
    </div>

    <div class="justify-center p-1 mx-3 md:w-xs ">
      <a href="{{url('/showProjects')}}">
        <button  class="w-full p-1 md:px-3 py-2  border-0 rounded-sm mx-3 md:mx-1  items-center gradient  hover:bg-cyan-600 hover:cursor-pointer text-white text-xs ">Browse Projects</button></a>
    </div>
  </div>
</div>
    <!-- /.content-header -->

    <!-- Main content -->
            <!-- Ublode section -->
            <div class="w-10/12 md:w-11/12 my-1 mx-auto p-2  bg-white rounded-md py-2 text-sm">
            <h1 class="text-base md:text-2xl text-center p-b-4 txet-cyan-950 border-b-2 border-b-stone-300 ">Upload Projects</h1>
            <form action="{{url('uploadProject')}}" method="post" enctype="multipart/form-data">
              @csrf
              <div class="block md:flex md:flex-wrap py-2 px-0 md:px-4 justify-center">
                <div class="flex flex-wrap justify-center items-center w-11/12 md:w-1/2 p-b-1 my-1 mx-auto">
                  <label class="w-full text-cyan-950 text-md m-1 " for="pname">Title</label>
                  <input class="block p-2.5 w-full text-sm text-gray-900 bg-gray-50 rounded-lg border border-gray-300 mx-1" type="text"
                          id="pname"
                          name="name"
                          placeholder="Enter Project Title" required/>
                </div>


                





                <div class="flex flex-wrap justify-center items-center w-11/12 md:w-1/2 p-b-1 my-1 mx-auto">
                    <!-- <label class="w-full text-cyan-950 text-md m-1 " for="ressp">Research specialization</label>
                    <input class="block p-2.5 w-full text-sm text-gray-900 bg-gray-50 rounded-lg border border-gray-300 mx-1" type="text"
                            id="ResearchSpecialization"
                            name="research_specialization"
                            placeholder="Enter the specialty " required/> -->
                      <label class="w-full text-cyan-950 text-md m-1 " for="ressp">Research Specialization</label>
                      <select style="color:gray" id="ResearchSpecialization" name="research_specialization" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5  dark:placeholder-gray-400 dark:focus:ring-blue-500 dark:focus:border-blue-500" required>
                        <option value="">Choose a Option</option>
                        <option value="Artificial intelligence">Artificial Intelligence</option>
                        <option value="Cybersecurity">Cybersecurity</option>
                        <option value="Mobile applications">Mobile Applications</option>
                        <option value="Internet Of Things">Internet Of Things</option>
                        <option value="Automated systems">Automated Systems</option>
                        <option value="Classification methods">Classification Methods</option>
                      </select>
                  </div>





                  <div class="flex flex-wrap justify-center items-center w-11/12 md:w-1/2 p-b-1 my-1 mx-auto">
                    <label class="w-full text-cyan-950 text-md m-1 " for="sname">Supervisor Name</label>
                    <input class="block p-2.5 w-full text-sm text-gray-900 bg-gray-50 rounded-lg border border-gray-300 mx-1" type="text"
                            id="sname"
                            name="supervisor_name"
                            placeholder="Enter supervisor name " required/>
                  </div>
                  <div class="flex flex-wrap justify-center items-center w-11/12 md:w-1/2 p-b-1 my-1 mx-auto">
                    <label class="w-full text-cyan-950 text-md m-1 " for="stname">Students Name</label>
                    <input class="block p-2.5 w-full text-sm text-gray-900 bg-gray-50 rounded-lg border border-gray-300 mx-1" type="text"
                            id="stname"
                            name="students_name"
                            placeholder="Enter students name" required/>
                  </div>
                  <div class="flex flex-wrap justify-center items-center w-11/12 md:w-1/2 p-b-1 my-1 mx-auto">
                    <label class="w-full text-cyan-950 text-md m-1 " for="date">Upload Date</label> <!-- Today's date is automatically entered -->
                    <input class="block p-2.5 w-full text-sm bg-gray-50 rounded-lg border border-gray-300 mx-1 text-stone-400  " id="date" type="date" name="uploade_date" value="{{date('Y-m-d',time())}}" required>
                  </div>

                  <div class="flex flex-wrap justify-center items-center w-11/12 md:w-1/2 p-b-1 my-1 mx-auto">
                    <label class="w-full text-cyan-950 text-md m-1 " for="link">URL</label> <!-- URL for pdf -->
                    <input class="block p-2.5 w-full text-sm text-gray-900 bg-gray-50 rounded-lg border border-gray-300 mx-1" id="link" type="url" name="url" required>
                  </div>

                  <div class="flex flex-wrap justify-center items-center w-11/12 md:w-full p-b-1 my-1 mx-auto">
                    <label class="w-full text-cyan-950 text-md m-1 " for="link">Abstract</label>
                    <textarea name="narration" id="message" rows="4" class="block p-2.5 w-full text-sm text-gray-900 bg-gray-50 rounded-lg border border-gray-300 " placeholder="Write abstract of your project here ..." required></textarea>
                  </div>

                  
                  <div class="text-center md:text-right oferflow-hidden w-full my-3 mx-auto text-md rounded-sm text-white ">
                    <button class="w-5/12 md:w-2/12 md:text-center  m-0 p-1 text-md rounded-sm text-white bg-cyan-950 hover:bg-stone-300 hover:text-cyan-950">Upload</button>
                  </div>
            </div>
          </div>

    <!-- /.content -->
@endsection