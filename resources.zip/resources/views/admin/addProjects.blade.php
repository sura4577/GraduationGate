@extends('admin.layouts.app')

@section('content')
    <!-- Content Header (Page header) -->
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0">{{ __('Add Project') }}</h1>
                    
                </div><!-- /.col -->
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">
                            <form action="{{url('addProjects')}}" method="post" enctype="multipart/form-data">
                                @csrf
                                <div class="row mb-4">
                                    <div class="col-md-6">
                                        <label>Project Name</label>
                                        <input type="text" class="form-control projectName mb-1" name="projectName" placeholder="Enter Project Name">

                                        <label for="">Documents</label>
                                        <div class="documentCol">
                                            <div class="row mb-1 documentRow">
                                                <div class="col-md-9">
                                                    <input type="file" class="form-control projectFile" name="projectFile[]">
                                                </div>
                                                <div class="col-md-3">
                                                    <button type="button" class="btn btn-primary" onclick="addRow(this)"><span class="fa fa-plus"></span></button>
                                                    <button  type="button" class="btn btn-danger" onclick="removeRow(this)"><span class="fa fa-minus"></span></button>
                                                </div>
                                            </div>
                                        </div>
                                        <label>Project Abstract</label>
                                        <textarea type="text" class="form-control projectNarration" name="projectNarration" placeholder="Enter Project Abstract"></textarea>
                                    </div>
                                </div>
                                <button class="btn btn-primary pull-right">Save</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content -->
    <script>
        function addRow(val_this){
            $('.documentCol').append($('.documentRow:first').clone())
            $('.documentRow:last').find('.projectFile').val('');
            
        }
        function removeRow(val_this){
           $(val_this).parent().parent('div').remove();
        }
    </script>
@endsection 