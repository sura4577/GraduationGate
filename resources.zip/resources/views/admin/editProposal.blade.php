@extends('admin.layouts.app')

@section('content')
    <!-- Content Header (Page header) -->
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0">{{ __('Edit Project') }}</h1>
                    
                </div><!-- /.col -->
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">
                            <form action="{{url('editProposal')}}" method="post" enctype="multipart/form-data">
                                @csrf
                                <div class="row mb-4">
                                    <div class="col-md-6">
                                        <label>Title</label>
                                        <input type="text" class="form-control mb-1" name="title" value="{{$proposal->title}}">
                                        <label> Supervisor Name</label>
                                        <input type="text" class="form-control mb-1" name="supervisor_name" value="{{$proposal->supervisor_name}}">
                                        <label>Research Specialization</label>
                                        <input type="text" class="form-control mb-1" name="research_specialization" value="{{$proposal->research_specialization}}">
                                        <label>Date Of Submission</label>
                                        <input  type="date" class="form-control mb-1" name="date_of_submission" value="{{date('Y-m-d', $proposal->date_of_submission)}}">
                                        <label>Proposal</label>
                                        <textarea type="text" class="form-control" name="proposal">{{$proposal->proposal}}</textarea>
                                        <input type="hidden" name="editProposalId" value="{{$proposal->id}}">
                                    </div>
                                </div>
                                <button class="btn btn-primary pull-right">Save</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content -->
    <script>
        function addRow(val_this){
            $('.documentCol').append($('.documentRow:first').clone())
            $('.documentRow:last').find('.editprojectFile').val('');
            
        }
        function removeRow(val_this){
           $(val_this).parent().parent('div').remove();
        }
    </script>
@endsection 