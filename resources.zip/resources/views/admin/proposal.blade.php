@extends('admin.layouts.app')

@section('content')
    <!-- Content Header (Page header) -->
    <div class="contentheader">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0">Proposals</h1>
                </div>
                <div class="col-sm-6">
                    <a class="btn btn-primary btn-lg float-right" href="{{ url('/UploadProposal') }}">Add Proposal</a>
                </div>
            </div>
            
        </div>
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        @if(Session::has('success'))
                            <div class="alert alert-success alert-dismissible show">
                                {{ session('success') }}
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                        @endif
                        @if(Session::has('error'))
                            <div class="alert alert-danger alert-dismissible show">
                                {{ session('error') }}
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                        @endif
                        <div class="card-body">
                            <table class="table" style="width:100%;">
                                <thead>
                                    <tr>
                                        <th style="width:5%">Sr</th>
                                        <th style="width:10%">title</th>
                                        <th style="width:25%">Speciealization</th>
                                        <th style="width:25%">proposal</th>
                                        <th style="width:10%">Action</th>
                                        
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach($proposals as $proposal)
                                        <tr>
                                           <td>{{$loop->iteration}}</td>
                                           <td>{{$proposal->title}}</td>
                                           <td>{{$proposal->research_specialization}}</td>
                                           <td>{{$proposal->proposal}}</td>
                                           <td>
                                                <a href="{{ route('showProposal',['id'=>$proposal->id]) }}" class="btn btn-primary">Edit</a>
                                                <a onclick="return confirm('Are You Sure To Delete')" href="{{ route('delProposal',['id'=>$proposal->id]) }}" class="btn btn-danger">Delete</a>
                                           </td> 
                                        </tr>
                                    @endforeach
                                </tbody>
                            </table>
                            {{$proposals}}
                         
                        </div>
                    </div>
                </div>
            </div>
            <!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content -->
@endsection