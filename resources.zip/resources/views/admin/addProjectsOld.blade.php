@extends('admin.layouts.app')

@section('content')
    <!-- Content Header (Page header) -->
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0">{{ __('Projects') }}</h1>
                    
                </div><!-- /.col -->
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">
                            <form action="{{url('addProjects')}}" method="post" enctype="multipart/form-data">
                                @csrf
                                <table class="table" style="width:100%;">
                                    <thead>
                                        <tr>
                                            <th style="width:5%">Sr</th>
                                            <th style="width:40%">Name</th>
                                            <th style="width:40%">File</th>
                                            <th style="width:15%">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody class="projectBody">
                                        <tr class="projectTr">
                                            <td class="projectNo">1</td>
                                            <td><input type="text" class="form-control projectName" name="projectName[]" placeholder="Enter Project Name"></td>
                                            <td><input type="file" class="form-control projectFile" name="projectFile[]"></td>
                                            <td><button type="button" class="btn btn-primary"><span class="fa fa-plus" onclick="addRow(this)"></span></button>
                                            <button  type="button" class="btn btn-danger"><span class="fa fa-minus" onclick="removeRow(this)"></span></button></td>
                                        </tr>
                                    </tbody>
                                </table>
                                <button class="btn btn-primary pull-right">Save</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content -->
    <script>
        function addRow(val_this){
            $('.projectBody').append($('.projectTr:first').clone())
            no = $('.projectBody').find('tr').length;
            $('.projectTr:last').find('.projectNo').text(no)
            $('.projectTr:last').find('.projectName').val('')
            $('.projectTr:last').find('.projectFile').val('')
        }
        function removeRow(val_this){
           $(val_this).parent().parent().parent().parent().find('tr').remove();
        }
    </script>
@endsection 