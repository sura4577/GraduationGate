@extends('admin.layouts.app')

@section('content')
    <!-- Content Header (Page header) -->
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0">{{ __('Edit Project') }}</h1>
                    
                </div><!-- /.col -->
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">
                            <form action="{{url('editProject')}}" method="post" enctype="multipart/form-data">
                                @csrf
                                <div class="row mb-4">
                                    <div class="col-md-6">
                                        <label>Project Name</label>
                                        <input type="text" class="form-control editprojectName mb-1" name="editprojectName" placeholder="Enter Project Name" value="{{$project->name}}">

                                        <label for="">Documents</label><br>
                                        @php
                                            $projectFiles = DB::table('project_files')->where('project_id', intval($project->id))->get();
                                        @endphp
                                        @foreach ($projectFiles as $projectFile)
                                            <a href="{{ URL::to('/') }}/uploades/{{ $projectFile->file }}"> 
                                                @php
                                                    $ext = pathinfo($projectFile->file ,PATHINFO_EXTENSION);
                                                    if($ext == 'pdf'){
                                                @endphp
                                                    <img style="width:50px;height:50px" src="{{ URL::to('/') }}/images/dummyFile.png" alt="">
                                                @php }else{ @endphp
                                                    <img style="width:50px;height:50px" src="{{ URL::to('/') }}/uploades/{{ $projectFile->file }}" alt="">
                                                @php } @endphp
                                            </a>   
                                        @endforeach
                                        <div class="documentCol">
                                            <div class="row mb-1 documentRow">
                                                <div class="col-md-9">
                                                    <input type="file" class="form-control editprojectFile" name="editprojectFile[]">
                                                </div>
                                                <div class="col-md-3">
                                                    <button type="button" class="btn btn-primary" onclick="addRow(this)"><span class="fa fa-plus"></span></button>
                                                    <button  type="button" class="btn btn-danger" onclick="removeRow(this)"><span class="fa fa-minus"></span></button>
                                                </div>
                                            </div>
                                        </div>
                                        <label>Project Abstract</label>
                                        <input type="hidden" name="editProjectId" value="{{$project->id}}">
                                        <textarea type="text" class="form-control editprojectNarration" name="editprojectNarration" placeholder="Enter Project Narration">{{$project->narration}}</textarea>
                                    </div>
                                </div>
                                <button class="btn btn-primary pull-right">Save</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content -->
    <script>
        function addRow(val_this){
            $('.documentCol').append($('.documentRow:first').clone())
            $('.documentRow:last').find('.editprojectFile').val('');
            
        }
        function removeRow(val_this){
           $(val_this).parent().parent('div').remove();
        }
    </script>
@endsection 