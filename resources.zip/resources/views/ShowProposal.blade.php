@include('includes.head')

    <body  class=" leading-normal tracking-normal bg-[#F0F3F4] min-h-screen flex flex-col" >
         <!--Nav-->
         @include('includes.header')
    

<nav class="flex mb-4 mx-3 my-2" aria-label="Breadcrumb">
  <ol class="inline-flex items-center space-x-1 md:space-x-3">
    <li class="inline-flex items-center">
    @auth
      <a href="{{ url('/HomeAsGPC') }}" class="inline-flex items-center text-sm font-medium text-cyan-950  underline  "> 
        Home
      </a>
      @endauth
      @guest
      <a href="{{ url('/') }}" class="inline-flex items-center text-sm font-medium text-cyan-950  underline  "> 
        Home
      </a>
      @endguest
    </li>
    <li aria-current="page">
      <div class="flex items-center">
        <svg class="w-3 h-3 text-[#005299] mx-1" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 6 10">
          <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m1 9 4-4-4-4"/>
        </svg>
        <span class="ml-1 text-sm font-medium text-[#0891B2] md:ml-2 ">Proposals</span>
      </div>
    </li>
  </ol>
</nav>




 


    <div id="print-content"  class="flex flex-wrap justify-center text-center text-sm md:w-full w-11/12 mx-auto flex-grow">
      
   <div  class=" w-full md:w-10/12 flex items-center print-hidden">
              <div class="w-8/12 md:w-9/12 ">
                <h1 class="text-left text-xl  md:ml-8"> Proposals :</h1> 
              </div>

              <div class="w-2/12 p-1 print-hidden"> 
              <button onclick="openPrintPopup()" class="w-full md:w-10/12 p-1 gradient text-white border-0 rounded-sm mx-9 md:mx-10 items-center hover:bg-cyan-600 hover:cursor-pointer "><i class="fa fa-print text-white text-xs mr-1" aria-hidden="true"></i>Print</button>              </div>
           
                  <div class="flex justify-end p-2 md:p-1 print-hidden mr-6">
                    @if(Auth::check())
                    @if(Auth::user()->user_type!='student')
                    <a href="{{url('/UploadProposal')}}">
                        <button  class="w-full md:w-10/12 p-1 gradient text-white border-0 rounded-sm mx-10 md:mx-6 items-center hover:bg-cyan-600 hover:cursor-pointer "><i class="fa fa-upload text-white text-xs  mr-1" aria-hidden="true"> </i> Upload Proposal</button></a>
                        @endif
                        @endif
                </div>
              </div>

      <!-- Card -->
      @foreach($proposals as $proposal)
        <div class="md:w-80 p-6 bg-white border border-gray-200 rounded-lg shadow m-2 hover:bg-opacity-50 content print-hidden">
            <div class="md:h-36 print-hidden"> 
                  <h5 class="mb-2 text-lg md:text-md font-bold tracking-tight text-gray-900 line-clamp-2 ">{{$proposal->title}}</h5>
              <p class="mb-3 font-normal text-gray-700  text-left line-clamp-4  ">{{$proposal->proposal}}</p>
            </div>
            <div class="w-full flex flex-wrap items-center border-t-2 border-black-100 border-solid print-hidden">
              <a href="{{ route('readMoreProposal',['id'=>$proposal->id]) }}" class="float-left  px-3 py-2 text-sm font-medium text-center text-white gradient rounded-full  hover:bg-cyan-600 mt-2 print-hidden ">
                  Read more 
              </a>
              <p class="float-right text-stone-600 mt-2  text-xs text-end md:ml-20 ml-52 " ><b>{{date('m/d/Y',$proposal->created_at)}}</b></p>
            </div>
        </div>
      @endforeach




    </div>
    <div id="print-indicator" class="fixed top-0 left-0 right-0 bottom-0 bg-black bg-opacity-70 z-50 hidden">
    <p class="text-red-600 font-bold p-4 border-b border-l border-r border-t-0 border-red-600 border-opacity-90 border-4 bg-white bg-opacity-80  ">Please close the print page and then refresh the page.</p>
</div>
       
<!-- <div class="w-full flex items-center justify-cnter  px-4 py-3 sm:px-6">
    <div class="flex flex-1 justify-between sm:hidden">
      <a href="#" class="relative inline-flex items-center rounded-md border border-gray-300  bg-[#F0F3F4]  px-4 py-2 text-sm font-medium text-cyan-950  underline  hover:bg-gray-50"><i class="fa fa-angle-left" aria-hidden="true"></i>Previous</a>
      <a href="#" class="relative ml-3 inline-flex items-center rounded-md border border-gray-300  bg-[#F0F3F4]  px-4 py-2 text-sm font-medium text-cyan-950  underline  hover:bg-gray-50 "><i class="fa fa-angle-right" aria-hidden="true"></i> Next</a>
    </div> -->
  <div class=" sm:flex sm:flex-1 sm:items-center sm:justify-center ">
  <a href="#" class="relative inline-flex items-center bg-[#F0F3F4] rounded-l-md px-2 py-2 text-gray-400 ring-1 ring-inset ring-gray-300 hover:bg-gray-50 focus:z-20 ">
          <span class="sr-only">Previous</span>
          <svg class="h-5 w-5" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
            <path fill-rule="evenodd" d="M12.79 5.23a.75.75 0 01-.02 1.06L8.832 10l3.938 3.71a.75.75 0 11-1.04 1.08l-4.5-4.25a.75.75 0 010-1.08l4.5-4.25a.75.75 0 011.06.02z" clip-rule="evenodd" />
          </svg>
        </a>
      <nav class="isolate inline-flex -space-x-px rounded-md shadow-sm" aria-label="Pagination">
      @foreach ($proposals->links()->elements[0] as $link)
        <a href="{{ $link }}" aria-current="page" class="relative z-10 inline-flex items-center gradient px-4 py-2 text-sm font-semibold text-white @if ($link == $proposals->currentPage()) bg-gray-800 @else hover:bg-gray-700 @endif">
            {{ $loop->iteration }}
        </a>
    @endforeach
    <a href="#" class="relative inline-flex items-center  bg-[#F0F3F4]  rounded-r-md px-2 py-2 text-gray-400 ring-1 ring-inset ring-gray-300 hover:bg-gray-50 ">
          <span class="sr-only">Next</span>
          <svg class="h-5 w-5" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
            <path fill-rule="evenodd" d="M7.21 14.77a.75.75 0 01.02-1.06L11.168 10 7.23 6.29a.75.75 0 111.04-1.08l4.5 4.25a.75.75 0 010 1.08l-4.5 4.25a.75.75 0 01-1.06-.02z" clip-rule="evenodd" />
          </svg>
        </a>
      </nav>
    </div>
  </div>
  <!-- {{$proposals}} -->
</div>


<style>
    @media print {
        body * {
            visibility: hidden;
        }
        #print-content, #print-content * {
            visibility: visible;
        }
        #print-indicator {
    position: fixed;
    transform: translate(-50%, -50%);
    background-color: rgba(0, 0, 0, 0.5); /* Adjust the opacity as needed */
    color: white;
    padding: 20px;
    z-index: 50;
    display: none;
}
    }
</style><script>
    let printWindow;

    function openPrintPopup() {
        // Check if the print popup is already open
        if (printWindow && !printWindow.closed) {
            // If open, show the print indicator and return
            document.getElementById('print-indicator').style.display = 'block';
            return;
        }

        // Hide the print indicator
        document.getElementById('print-indicator').style.display = 'none';

        // Open a new print popup
        printWindow = window.open('', '_blank');

        // Show the print indicator even if the print pop-up is open
        document.getElementById('print-indicator').style.display = 'block';

        printWindow.document.write('<html><head><link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css"></head><body>');
        printWindow.document.write(document.getElementById('print-content').outerHTML);
        printWindow.document.write('</body></html>');
        printWindow.document.close();
        printWindow.print();
    }
</script>
  </container>
  @include('includes.footer')
  
  <script>
    var scrollpos = window.scrollY;
    var header = document.getElementById("header");
    var navcontent = document.getElementById("nav-content");
    var navaction = document.getElementById("navAction");
    var brandname = document.getElementById("brandname");
    var toToggle = document.querySelectorAll(".toggleColour");

    document.addEventListener("scroll", function() {
      /*Apply classes for slide in bar*/
      scrollpos = window.scrollY;

      if (scrollpos > 10) {
        header.classList.add("bg-[#F0F3F4] ");
        navaction.classList.remove("bg-[#F0F3F4] ");
        navaction.classList.add("gradient");
        navaction.classList.remove("text-gray-800");
        navaction.classList.add("text-white");
        //Use to switch toggleColour colours
        for (var i = 0; i < toToggle.length; i++) {
          toToggle[i].classList.add("text-gray-800");
          toToggle[i].classList.remove("text-white");
        }
        header.classList.add("shadow");
        navcontent.classList.remove("bg-gray-100");
        navcontent.classList.add("bg-[#F0F3F4] ");
      } else {
        header.classList.remove("bg-[#F0F3F4] ");
        navaction.classList.remove("gradient");
        navaction.classList.add("bg-[#F0F3F4] ");
        navaction.classList.remove("text-white");
        navaction.classList.add("text-gray-800");
        //Use to switch toggleColour colours
        for (var i = 0; i < toToggle.length; i++) {
          toToggle[i].classList.add("text-white");
          toToggle[i].classList.remove("text-gray-800");
        }

        header.classList.remove("shadow");
        navcontent.classList.remove("bg-[#F0F3F4] ");
        navcontent.classList.add("bg-gray-100");
      }
    });
  </script>
  <script>
    /*Toggle dropdown list*/
    /*https://gist.github.com/slavapas/593e8e50cf4cc16ac972afcbad4f70c8*/

    var navMenuDiv = document.getElementById("nav-content");
    var navMenu = document.getElementById("nav-toggle");

    document.onclick = check;

    function check(e) {
      var target = (e && e.target) || (event && event.srcElement);

      //Nav Menu
      if (!checkParent(target, navMenuDiv)) {
        // click NOT on the menu
        if (checkParent(target, navMenu)) {
          // click on the link
          if (navMenuDiv.classList.contains("hidden")) {
            navMenuDiv.classList.remove("hidden");
          } else {
            navMenuDiv.classList.add("hidden");
          }
        } else {
          // click both outside link and outside menu, hide menu
          navMenuDiv.classList.add("hidden");
        }
      }
    }

    function checkParent(t, elm) {
      while (t.parentNode) {
        if (t == elm) {
          return true;
        }
        t = t.parentNode;
      }
      return false;
    }
  </script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/flowbite/1.8.1/flowbite.min.js"></script>

</body>
</html>
