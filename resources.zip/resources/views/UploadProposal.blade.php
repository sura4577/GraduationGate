@include('includes.head')
    <body  class=" leading-normal tracking-normal bg-[#F0F3F4] min-h-screen flex flex-col" >
         <!--Nav-->
         @include('includes.header')



 
<nav class="flex mb-4 mx-3 my-2 " aria-label="Breadcrumb">
  <ol class="inline-flex items-center space-x-1 md:space-x-3">
    <li class="inline-flex items-center">
    @auth
      <a href="{{ url('/HomeAsGPC') }}" class="inline-flex items-center text-sm font-medium text-cyan-950  underline  "> 
        Home
      </a>
      @endauth
      @guest
      <a href="{{ url('/') }}" class="inline-flex items-center text-sm font-medium text-cyan-950  underline  "> 
        Home
      </a>
      @endguest

    </li>
      <li>
        <div class="flex items-center">
          <svg class="w-3 h-3 text-[#005299] mx-1" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 6 10">
            <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m1 9 4-4-4-4" />
          </svg>
          <a href="{{ url('/proposals') }}" class="ml-1 text-sm font-medium text-cyan-950  underline   md:ml-2">Proposals</a>
        </div>
      </li>
    <li aria-current="page">
      <div class="flex items-center">
        <svg class="w-3 h-3 text-[#005299] mx-1" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 6 10">
          <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m1 9 4-4-4-4"/>
        </svg>
        <span class="ml-1 text-sm font-medium text-[#0891B2] md:ml-2 ">Upload Propasal</span>
      </div>
    </li>
  </ol>
</nav>

      <!-- Upload Proposal from suberviser  -->
      <div class="w-11/12 md:w-8/12 my-0 mx-auto p-2  bg-white rounded-md text-sm  flex-grow">
          <h1 class="text-lg md:text-2xl text-center p-b-4 txet-cyan-950 border-b-2 border-b-stone-300 ">Upload Proposal</h1>
          <form action="{{url('addProposals')}}" method="post" enctype="multipart/form-data">
            @csrf
            <div class="block md:flex md:flex-wrap py-2 px-0 md:px-4 justify-center">
              <div class="flex flex-wrap justify-center items-center md:w-1/2 w-full p-b-1 my-1 mx-auto">
                <label class="w-full text-cyan-950 text-md m-1 " for="pTitle">Title</label>
                <input class="block p-2.5 w-full text-sm text-gray-900 bg-gray-50 rounded-lg border border-gray-300 mx-0 md:mx-1" type="text"
                        id="pTitle"
                        name="title"
                        placeholder="Enter project Title" required/>
              </div>
              <div class="flex flex-wrap justify-center items-center md:w-1/2 w-full p-b-1 my-1 mx-auto">
                <label class="w-full text-cyan-950 text-md m-1 " for="sname">Supervisor Name</label>
                <input class="block p-2.5 w-full text-sm text-gray-900 bg-gray-50 rounded-lg border border-gray-300 mx-0 md:mx-1" type="text"
                        id="sname"
                        name="supervisor_name"
                        placeholder="{{ __('Name') }}"
                        value="{{ old('name', auth()->user()->name) }}" required readonly/>
              </div>
              <div class="flex flex-wrap justify-center items-center md:w-1/2 w-full p-b-1 my-1 mx-auto">
              <label class="w-full text-cyan-950 text-md m-1 " for="ressp">Research Specialization</label>
                      <select style="color:gray" id="ResearchSpecialization"   name="research_specialization" class="block p-2.5 w-full text-sm text-gray-900 bg-gray-50 rounded-lg border border-gray-300 mx-0 md:mx-1 "  placeholder="Enter the specialty "  required>
                        <option value="">Choose a Option</option>
                        <option value="Artificial intelligence">Artificial intelligence</option>
                        <option value="Cybersecurity">Cybersecurity</option>
                        <option value="Mobile applications">Mobile applications</option>
                        <option value="Internet Of Things">Internet Of Things</option>
                        <option value="Automated systems">Automated systems</option>
                        <option value="Classification methods">Classification methods</option>
                      </select>
                </div>
                <div class="flex flex-wrap justify-center items-center md:w-1/2 w-full p-b-1 my-1 mx-auto">
                  <label class="w-full text-cyan-950 text-md m-1 " for="date">Date of Submission</label>
                  <input value="{{date('Y-m-d',time())}}" class="block p-2.5 w-full text-sm bg-gray-50 rounded-lg border border-gray-300 mx-0 md:mx-1 text-stone-400 w-5xl" type="date" name="date_of_submission" required>
                </div>
                <div class="flex flex-wrap justify-start items-center w-full p-b-1 my-1 ">
                  <label class="w-full text-cyan-950 text-md m-1 " for="link">Proposal</label>
                  <textarea name="proposal" id="message" rows="4" class="block p-2.5 w-full text-sm text-gray-900 bg-gray-50 rounded-lg border border-gray-300 " placeholder="Write brief description of your proposal here" required></textarea>                </div>
                
               
                  @if(session('success'))
        <div class="text-green-600 mt-2">Proposal Uploaded successfully.</div>
    @endif

    @if(session('error') && Auth::user()->user_type != 'admin')
        <div class="text-red-600 mt-2">Some Error Occure.</div>
    @endif
                
                <div class="text-center md:text-right oferflow-hidden w-full my-3 mx-auto text-md rounded-sm text-white ">
                  <button class="w-5/12 md:w-2/12 md:text-center  m-0 p-1 text-md rounded-sm text-white bg-cyan-950 hover:bg-stone-300 hover:text-cyan-950" >Upload Proposal</button>
                </div>
          </div>
        </div>


      


        </container>
        @include('includes.footer')
        
  <script>
    var scrollpos = window.scrollY;
    var header = document.getElementById("header");
    var navcontent = document.getElementById("nav-content");
    var navaction = document.getElementById("navAction");
    var brandname = document.getElementById("brandname");
    var toToggle = document.querySelectorAll(".toggleColour");

    document.addEventListener("scroll", function() {
      /*Apply classes for slide in bar*/
      scrollpos = window.scrollY;

      if (scrollpos > 10) {
        header.classList.add("bg-[#F0F3F4] ");
        navaction.classList.remove("bg-[#F0F3F4] ");
        navaction.classList.add("gradient");
        navaction.classList.remove("text-gray-800");
        navaction.classList.add("text-white");
        //Use to switch toggleColour colours
        for (var i = 0; i < toToggle.length; i++) {
          toToggle[i].classList.add("text-gray-800");
          toToggle[i].classList.remove("text-white");
        }
        header.classList.add("shadow");
        navcontent.classList.remove("bg-gray-100");
        navcontent.classList.add("bg-[#F0F3F4] ");
      } else {
        header.classList.remove("bg-[#F0F3F4] ");
        navaction.classList.remove("gradient");
        navaction.classList.add("bg-[#F0F3F4] ");
        navaction.classList.remove("text-white");
        navaction.classList.add("text-gray-800");
        //Use to switch toggleColour colours
        for (var i = 0; i < toToggle.length; i++) {
          toToggle[i].classList.add("text-white");
          toToggle[i].classList.remove("text-gray-800");
        }

        header.classList.remove("shadow");
        navcontent.classList.remove("bg-[#F0F3F4] ");
        navcontent.classList.add("bg-gray-100");
      }
    });
  </script>
  <script>
    /*Toggle dropdown list*/
    /*https://gist.github.com/slavapas/593e8e50cf4cc16ac972afcbad4f70c8*/

    var navMenuDiv = document.getElementById("nav-content");
    var navMenu = document.getElementById("nav-toggle");

    document.onclick = check;

    function check(e) {
      var target = (e && e.target) || (event && event.srcElement);

      //Nav Menu
      if (!checkParent(target, navMenuDiv)) {
        // click NOT on the menu
        if (checkParent(target, navMenu)) {
          // click on the link
          if (navMenuDiv.classList.contains("hidden")) {
            navMenuDiv.classList.remove("hidden");
          } else {
            navMenuDiv.classList.add("hidden");
          }
        } else {
          // click both outside link and outside menu, hide menu
          navMenuDiv.classList.add("hidden");
        }
      }
    }

    function checkParent(t, elm) {
      while (t.parentNode) {
        if (t == elm) {
          return true;
        }
        t = t.parentNode;
      }
      return false;
    }
  </script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/flowbite/1.8.1/flowbite.min.js"></script>

    </body><!-- End Body -->
</html>
