<!DOCTYPE html>
<html lang="en" class=" " >
    <head>
        <meta charset="utf-8">
        <link rel="icon" href="/resources/logo2.png" type="image/x-icon">
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <meta http-equiv="X-UA-Compatible" content="ie=edge" />
        <title>Graduation Gate</title>
        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Varela+Round&display=swap" rel="stylesheet">
        <!-- Css Files -->
        <link rel="stylesheet" href="css/font-awesome.min.css" />
        <link rel="stylesheet" href="output.css" />
        <link rel="stylesheet" href="https://unpkg.com/tailwindcss@2.2.19/dist/tailwind.min.css"/>
    <!--Replace with your tailwind.css once created-->
    <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:400,700" rel="stylesheet" />
    <!-- Define your gradient here - use online tools to find a gradient matching your branding-->
        <script src="https://cdn.tailwindcss.com"></script>
        <style>
      .gradient {
        background: linear-gradient(30deg, #005299 0%, #0891B2 100%);
      }
    </style>

    </head><!-- End Head -->
    <body  class=" leading-normal tracking-normal bg-[#F0F3F4] " >
         <!--Nav-->
         @include('includes.header')
    <script>
      var scrollpos = window.scrollY;
      var header = document.getElementById("header");
      var navcontent = document.getElementById("nav-content");
      var navaction = document.getElementById("navAction");
      var brandname = document.getElementById("brandname");
      var toToggle = document.querySelectorAll(".toggleColour");

      document.addEventListener("scroll", function () {
        /*Apply classes for slide in bar*/
        scrollpos = window.scrollY;

        if (scrollpos > 10) {
          header.classList.add("bg-[#F0F3F4] ");
          navaction.classList.remove("bg-[#F0F3F4] ");
          navaction.classList.add("gradient");
          navaction.classList.remove("text-gray-800");
          navaction.classList.add("text-white");
          //Use to switch toggleColour colours
          for (var i = 0; i < toToggle.length; i++) {
            toToggle[i].classList.add("text-gray-800");
            toToggle[i].classList.remove("text-white");
          }
          header.classList.add("shadow");
          navcontent.classList.remove("bg-gray-100");
          navcontent.classList.add("bg-[#F0F3F4] ");
        } else {
          header.classList.remove("bg-[#F0F3F4] ");
          navaction.classList.remove("gradient");
          navaction.classList.add("bg-[#F0F3F4] ");
          navaction.classList.remove("text-white");
          navaction.classList.add("text-gray-800");
          //Use to switch toggleColour colours
          for (var i = 0; i < toToggle.length; i++) {
            toToggle[i].classList.add("text-white");
            toToggle[i].classList.remove("text-gray-800");
          }

          header.classList.remove("shadow");
          navcontent.classList.remove("bg-[#F0F3F4] ");
          navcontent.classList.add("bg-gray-100");
        }
      });
    </script>
    <script>
      /*Toggle dropdown list*/
      /*https://gist.github.com/slavapas/593e8e50cf4cc16ac972afcbad4f70c8*/

      var navMenuDiv = document.getElementById("nav-content");
      var navMenu = document.getElementById("nav-toggle");

      document.onclick = check;
      function check(e) {
        var target = (e && e.target) || (event && event.srcElement);

        //Nav Menu
        if (!checkParent(target, navMenuDiv)) {
          // click NOT on the menu
          if (checkParent(target, navMenu)) {
            // click on the link
            if (navMenuDiv.classList.contains("hidden")) {
              navMenuDiv.classList.remove("hidden");
            } else {
              navMenuDiv.classList.add("hidden");
            }
          } else {
            // click both outside link and outside menu, hide menu
            navMenuDiv.classList.add("hidden");
          }
        }
      }
      function checkParent(t, elm) {
        while (t.parentNode) {
          if (t == elm) {
            return true;
          }
          t = t.parentNode;
        }
        return false;
      }
    </script>
            
<nav class="flex mb-4 mx-3 my-2" aria-label="Breadcrumb">
  <ol class="inline-flex items-center space-x-1 md:space-x-3">
    <li class="inline-flex items-center">
      <a href="Home.html" class="inline-flex items-center text-sm font-medium text-gray-700 "> 
        Home
      </a>
    </li>
    <li>
      <div class="flex items-center">
        <svg class="w-3 h-3 text-gray-400 mx-1" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 6 10">
          <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m1 9 4-4-4-4"/>
        </svg>
        <a href="projects.html" class="ml-1 text-sm font-medium text-gray-700  md:ml-2">Projects</a>
      </div>
    </li>
    <li aria-current="page">
      <div class="flex items-center">
        <svg class="w-3 h-3 text-gray-400 mx-1" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 6 10">
          <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m1 9 4-4-4-4"/>
        </svg>
        <span class="ml-1 text-sm font-medium text-gray-500 md:ml-2 ">Groups</span>
      </div>
    </li>
  </ol>
</nav>

<div class=" flex overflow-x-auto shadow-md sm:rounded-lg border-t-2 border-stone-300 text-sm">
  <div  class="w-full flex items-center ">
    <div class="w-10/12 md:w-11/12 p-2 flex items:center mb-2">
      <h1 class="text-left text-xl  "> Groups </h1> 
    </div>

    <div class="justify-center p-1 mx-3 md:w-xs ">
      <a href="{{url('/AddGroup')}}">
        <button  class="w-full p-1 md:px-3  border-0 rounded-sm mx-1 md:mx-1 items-center gradient  hover:bg-cyan-600 hover:cursor-pointer text-white text-xs "><i class="fa fa-plus text-white  px-1 " aria-hidden="true"></i>Add Group</button></a>
    </div>
  </div>
</div>


  


              
          
              <div class="overflow-auto rounded-lg shadow hidden md:block  md:mx-2">
                <table class="w-full">
                  <thead class="bg-gray-50 border-b-2 border-gray-200">
                  <tr>
                    <th class="w-20 p-2 text-sm font-semibold tracking-wide text-left">Group number</th>
                    <th class="w-20 p-3 text-sm font-semibold tracking-wide text-left">Studentes name</th>
                    <th class="p-3 text-sm font-semibold tracking-wide text-center">Priorities List</th>
                    <th class="p-3 text-sm font-semibold tracking-wide text-center">Actions</th>
                   </tr>
                  </thead>
                  <tbody class="divide-y divide-gray-100">


                  @foreach($groups as $group)
                  <tr class="bg-white">
                    <td class="p-3 text-sm text-gray-700 whitespace-nowrap">
                      <a href="#" class="font-bold text-cyan-950 hover:underline">{{$group->group_number}}</a>
                    </td>
                    <td class="p-3 text-sm text-gray-700 whitespace-nowrap">
                      {{$group->students_name}}
                    </td>
                    <td class="p-3 text-sm text-gray-700 whitespace-wrap">    {{$group->priorities_list}}
                    </td>
                    <td class="p-3 text-sm text-gray-700 whitespace-nowrap">
                    <div class="  flex  items-centter">
                      <a href="#">
                        <button class=" p-2 border-0 rounded-sm m-1 bg-stone-200 hover:bg-cyan-950  hover:opacity-3 "><i class="fa fa-pencil-square-o text-cyan-600 hover:text-white" aria-hidden="true"></i> </button></a>
                      <a href="#">
                          <button class=" p-2 border-0 rounded-sm m-1 bg-stone-200  hover:bg-cyan-950   hover:opacity-3 "><i class="fa fa-trash text-cyan-600 hover:text-white" aria-hidden="true"></i></button></a>
                    </div>   
                    </td>
                  </tr>
                  @endforeach




                  </tbody>


                  <!-- <tbody class="divide-y divide-gray-100">
                  <tr class="bg-white">
                    <td class="p-3 text-sm text-gray-700 whitespace-nowrap">
                      <a href="#" class="font-bold text-cyan-950 hover:underline">Group number</a>
                    </td>
                    <td class="p-3 text-sm text-gray-700 whitespace-nowrap">
                       Call Studente name <br>
                       Call Studente name <br>
                       Call Studente name
                    </td>
                    <td class="p-3 text-sm text-gray-700 whitespace-wrap"> Priorities List Priorities List Priorities List Priorities List Priorities List
                        Priorities List Priorities List Priorities List Priorities List Priorities List
                        Priorities List Priorities List Priorities List Priorities List Priorities List
                        Priorities List Priorities List Priorities List Priorities List Priorities List
                        Priorities List Priorities List Priorities List Priorities List Priorities List
                        Priorities List Priorities List Priorities List Priorities List Priorities List
                        Priorities List Priorities List Priorities List Priorities List Priorities List
                        Priorities List Priorities List Priorities List Priorities List Priorities List 
                    </td>
                    <td class="p-3 text-sm text-gray-700 whitespace-nowrap">
                    <div class="  flex  items-centter">
                      <a href="#">
                        <button class=" p-2 border-0 rounded-sm m-1 bg-stone-200 hover:bg-cyan-950  hover:opacity-3 "><i class="fa fa-pencil-square-o text-cyan-600 hover:text-white" aria-hidden="true"></i> </button></a>
                      <a href="#">
                          <button class=" p-2 border-0 rounded-sm m-1 bg-stone-200  hover:bg-cyan-950   hover:opacity-3 "><i class="fa fa-trash text-cyan-600 hover:text-white" aria-hidden="true"></i></button></a>
                    </div>   
                    </td>
                  </tr>

                  </tbody>


                  <tbody class="divide-y divide-gray-100">
                  <tr class="bg-white">
                    <td class="p-3 text-sm text-gray-700 whitespace-nowrap">
                      <a href="#" class="font-bold text-cyan-950 hover:underline">Group number</a>
                    </td>
                    <td class="p-3 text-sm text-gray-700 whitespace-nowrap">
                       Call Studente name <br>
                       Call Studente name <br>
                       Call Studente name
                    </td>
                    <td class="p-3 text-sm text-gray-700 whitespace-wrap"> Priorities List Priorities List Priorities List Priorities List Priorities List
                        Priorities List Priorities List Priorities List Priorities List Priorities List
                        Priorities List Priorities List Priorities List Priorities List Priorities List
                        Priorities List Priorities List Priorities List Priorities List Priorities List
                        Priorities List Priorities List Priorities List Priorities List Priorities List
                        Priorities List Priorities List Priorities List Priorities List Priorities List
                        Priorities List Priorities List Priorities List Priorities List Priorities List
                        Priorities List Priorities List Priorities List Priorities List Priorities List 
                    </td>
                    <td class="p-3 text-sm text-gray-700 whitespace-nowrap">
                    <div class="  flex  items-centter">
                      <a href="#">
                        <button class=" p-2 border-0 rounded-sm m-1 bg-stone-200 hover:bg-cyan-950  hover:opacity-3 "><i class="fa fa-pencil-square-o text-cyan-600 hover:text-white" aria-hidden="true"></i> </button></a>
                      <a href="#">
                          <button class=" p-2 border-0 rounded-sm m-1 bg-stone-200  hover:bg-cyan-950   hover:opacity-3 "><i class="fa fa-trash text-cyan-600 hover:text-white" aria-hidden="true"></i></button></a>
                    </div>   
                    </td>
                  </tr>

                  </tbody> -->
                </table>
              </div>

              <!--in smail screen --> 
              <div class="grid grid-cols-1 sm:grid-cols-2 gap-4 md:hidden">
                <div class="bg-white space-y-3 p-4 rounded-lg shadow">
                  <div class="space-x-2 text-sm">
                      <p class="text-cyan-950 font-bold hover:underline">Group number</p>
                  </div>
                  <div class="text-sm text-gray-700">
                    Priorities List Priorities List Priorities List Priorities List Priorities List
                    Priorities List Priorities List Priorities List Priorities List Priorities List
                    Priorities List Priorities List Priorities List Priorities List Priorities List
                    Priorities List Priorities List Priorities List Priorities List Priorities List
                    Priorities List Priorities List Priorities List Priorities List Priorities List
                    Priorities List Priorities List Priorities List Priorities List Priorities List
                    Priorities List Priorities List Priorities List Priorities List Priorities List
                    Priorities List Priorities List Priorities List Priorities List Priorities List
                  </div>
                  <div class="flex flex-wrap items-center "> 
                  <p class="text-sm font-medium text-black">Studente name - Studente name - Studente name </p>
                  <div class=" flex  items-centter ml-16">
                      <a href="#">
                        <button class=" p-2 border-0 rounded-sm m-1 bg-stone-200 hover:bg-cyan-950  hover:opacity-3 "><i class="fa fa-pencil-square-o text-cyan-600 hover:text-white" aria-hidden="true"></i> </button></a>
                      <a href="#">
                          <button class=" p-2 border-0 rounded-sm m-1 bg-stone-200  hover:bg-cyan-950   hover:opacity-3 "><i class="fa fa-trash text-cyan-600 hover:text-white" aria-hidden="true"></i></button></a>
                    </div>   
                  </div>
                </div>

                <div class="bg-white space-y-3 p-4 rounded-lg shadow">
                  <div class="space-x-2 text-sm">
                      <p class="text-cyan-950 font-bold hover:underline">Group number</p>
                  </div>
                  <div class="text-sm text-gray-700">
                    Priorities List Priorities List Priorities List Priorities List Priorities List
                    Priorities List Priorities List Priorities List Priorities List Priorities List
                    Priorities List Priorities List Priorities List Priorities List Priorities List
                    Priorities List Priorities List Priorities List Priorities List Priorities List
                    Priorities List Priorities List Priorities List Priorities List Priorities List
                    Priorities List Priorities List Priorities List Priorities List Priorities List
                    Priorities List Priorities List Priorities List Priorities List Priorities List
                    Priorities List Priorities List Priorities List Priorities List Priorities List
                  </div>
                  <div class="flex flex-wrap items-center "> 
                  <p class="text-sm font-medium text-black">Studente name - Studente name - Studente name </p>
                  <div class=" flex  items-centter ml-16">
                      <a href="#">
                        <button class=" p-2 border-0 rounded-sm m-1 bg-stone-200 hover:bg-cyan-950  hover:opacity-3 "><i class="fa fa-pencil-square-o text-cyan-600 hover:text-white" aria-hidden="true"></i> </button></a>
                      <a href="#">
                          <button class=" p-2 border-0 rounded-sm m-1 bg-stone-200  hover:bg-cyan-950   hover:opacity-3 "><i class="fa fa-trash text-cyan-600 hover:text-white" aria-hidden="true"></i></button></a>
                    </div>   
                  </div>
                </div>

                <div class="bg-white space-y-3 p-4 rounded-lg shadow">
                  <div class="space-x-2 text-sm">
                      <p class="text-cyan-950 font-bold hover:underline">Group number</p>
                  </div>
                  <div class="text-sm text-gray-700">
                    Priorities List Priorities List Priorities List Priorities List Priorities List
                    Priorities List Priorities List Priorities List Priorities List Priorities List
                    Priorities List Priorities List Priorities List Priorities List Priorities List
                    Priorities List Priorities List Priorities List Priorities List Priorities List
                    Priorities List Priorities List Priorities List Priorities List Priorities List
                    Priorities List Priorities List Priorities List Priorities List Priorities List
                    Priorities List Priorities List Priorities List Priorities List Priorities List
                    Priorities List Priorities List Priorities List Priorities List Priorities List
                  </div>
                  <div class="flex flex-wrap items-center "> 
                  <p class="text-sm font-medium text-black">Studente name - Studente name - Studente name </p>
                  <div class=" flex  items-centter ml-16">
                      <a href="#">
                        <button class=" p-2 border-0 rounded-sm m-1 bg-stone-200 hover:bg-cyan-950  hover:opacity-3 "><i class="fa fa-pencil-square-o text-cyan-600 hover:text-white" aria-hidden="true"></i> </button></a>
                      <a href="#">
                          <button class=" p-2 border-0 rounded-sm m-1 bg-stone-200  hover:bg-cyan-950   hover:opacity-3 "><i class="fa fa-trash text-cyan-600 hover:text-white" aria-hidden="true"></i></button></a>
                    </div>   
                  </div>
                </div>

                <div class="bg-white space-y-3 p-4 rounded-lg shadow">
                  <div class="space-x-2 text-sm">
                      <p class="text-cyan-950 font-bold hover:underline">Group number</p>
                  </div>
                  <div class="text-sm text-gray-700">
                    Priorities List Priorities List Priorities List Priorities List Priorities List
                    Priorities List Priorities List Priorities List Priorities List Priorities List
                    Priorities List Priorities List Priorities List Priorities List Priorities List
                    Priorities List Priorities List Priorities List Priorities List Priorities List
                    Priorities List Priorities List Priorities List Priorities List Priorities List
                    Priorities List Priorities List Priorities List Priorities List Priorities List
                    Priorities List Priorities List Priorities List Priorities List Priorities List
                    Priorities List Priorities List Priorities List Priorities List Priorities List
                  </div>
                  <div class="flex flex-wrap items-center "> 
                  <p class="text-sm font-medium text-black">Studente name - Studente name - Studente name </p>
                  <div class=" flex  items-centter ml-16">
                      <a href="#">
                        <button class=" p-2 border-0 rounded-sm m-1 bg-stone-200 hover:bg-cyan-950  hover:opacity-3 "><i class="fa fa-pencil-square-o text-cyan-600 hover:text-white" aria-hidden="true"></i> </button></a>
                      <a href="#">
                          <button class=" p-2 border-0 rounded-sm m-1 bg-stone-200  hover:bg-cyan-950   hover:opacity-3 "><i class="fa fa-trash text-cyan-600 hover:text-white" aria-hidden="true"></i></button></a>
                    </div>   
                  </div>
                </div>



                  

                  
              </div>
            </div>
          </div>
  
       
       
   
</div>



   
  
  </container>
</body>
</html>

