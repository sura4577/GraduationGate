<nav id="header" class="fixed w-full z-30 top-0 text-white gradient">

      <div class="container flex flex-wrap items-center mt-0 py-2 ">
        <div class="w-2/12 md:w-1/12 flex flex-wrap items-center justify-start p-4">
        <a href="{{ url('/') }}" class="flex items-center ">
            <img src="{{ asset('images/logo1r.png') }}" class="h-8 " alt="Logo">
            </a>
        </div>

        <div class="w-8/12 md:w-4/12 flex items-center justify-end md:order-2 p-1  ">
            @if (Route::has('login'))
                    @auth
                    <div class="relative group invisible md:visible lg:visible">
                    <button id="userDropdown" class="text-white no-underline hover:text-cyan-950 py-2 px-4 focus:outline-none">
                    <i class="fa fa-user text-white pr-1" aria-hidden="true"></i> {{ Auth::user()->name }} <i class="fa fa-caret-down text-white" aria-hidden="true"></i>
                </button>
                <div id="userDropdownMenu" class="absolute right-0 hidden bg-white rounded-md w-44 text-white mt-2  ">
               <a href="{{ route('user.fav') }}" class="no-underline text-cyan-950">
                <button class="mx-auto lg:mx-1 mr-1 bg-white text-cyan-950 md:py-1 md:px-2 px-1 transform transition hover:scale-105 duration-300">
                    <i class="fa fa-star fa-sm pr-1 " aria-hidden="true"></i>Favorites List
                </button>
            </a>
            <div class="dropdown-divider"></div>
            <a href="{{ route('profile.show') }}" class="no-underline text-cyan-950">
                <button class="mx-auto lg:mx-1 mr-1 bg-white text-cyan-950 md:py-1 md:px-2 px-1 transform transition hover:scale-105 duration-300">
                <i class="fa fa-pencil-square-o fa-sm pr-1" aria-hidden="true"></i>Change Password
                </button>
            </a>
            <div class="dropdown-divider"></div>
                        <form method="POST" action="{{ route('logout') }}">
                            @csrf
                            <a href="{{ route('logout') }}" onclick="event.preventDefault(); this.closest('form').submit();" class="no-underline text-cyan-950 "> <button class="mx-auto lg:mx-1  bg-white  md:py-1 md:px-2 px-1  transform transition hover:scale-105  duration-300"><i class="fa fa-sign-out pr-1" aria-hidden="true"></i>Log out</button></a>
                        </form>
                    @else
                    <div class="relative group invisible md:visible lg:visible">
                    <button id="userDropdown" class="text-white no-underline hover:text-cyan-950 py-2 px-4 focus:outline-none">
                    <i class="fa fa-user text-white pr-1" aria-hidden="true"></i> My Account <i class="fa fa-caret-down text-white" aria-hidden="true"></i>
                </button>
                <div id="userDropdownMenu" class="absolute right-0  hidden bg-white text-white mt-2 w-36">
               <a href="{{ route('login') }}" class="no-underline text-cyan-950">
                <button class="mx-auto lg:mx-1 mr-1 bg-white text-cyan-950 md:py-1 md:px-2 px-1 transform transition hover:scale-105 duration-300">
                <i class="fa fa-sign-in fa-sm pr-1" aria-hidden="true"></i> Log in
                </button>
            </a>
            <div class="dropdown-divider"></div>
            <a href="{{ route('register') }}" class="no-underline text-cyan-950">
                <button class="mx-auto lg:mx-1 mr-1 bg-white text-cyan-950 md:py-1 md:px-2 px-1 transform transition hover:scale-105 duration-300">
                <i class="fa fa-user-plus fa-sm pr-1" aria-hidden="true"></i> Sing Up 
                </button>
            </a>
            <div class="dropdown-divider"></div>
                    @endauth
              
            @endif
        </div>   <script>
                document.getElementById('userDropdown').addEventListener('click', function () {
                    document.getElementById('userDropdownMenu').classList.toggle('hidden');
                });
            </script>
      </div>
                   
        </div>

     
               
           


      

        <div class="block md:hidden pr-1">
          <button id="nav-toggle" class="flex items-center p-1 text-white hover:text-cyan-950 focus:outline-none focus:shadow-outline transform transition hover:scale-105 duration-300 ease-in-out">
            <svg class="fill-current h-8 w-8" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
              <title>Menu</title>
              <path d="M0 3h20v2H0V3zm0 6h20v2H0V9zm0 6h20v2H0v-2z" />
            </svg>
          </button>
        </div>
        
       
        

        <div class="w-full md:w-7/12 flex-grow md:flex md:items-center md:justify-center  hidden mt-2 md:mt-0 bg-transparent md:bg-transparent text-cyan-950 p-4 md:p-0 z-20  " id="nav-content">
            <ul class="w-full list-reset md:flex justify-center flex-1 items-center " >
                <li class="mr-3">
                @auth
                    <a class="inline-block text-white no-underline hover:text-cyan-950 py-2 px-4" href="{{ url('/HomeAsGPC') }}">Home</a>
                
                @endauth
                @guest
                     <a class="inline-block text-white no-underline hover:text-cyan-950 py-2 px-4" href="{{ url('/') }}">Home</a>
                @endguest
                </li>
                @auth
                    @if(auth()->user()->user_type == 'admin')
                        <li class="mr-3">
                            <a class="inline-block text-white no-underline hover:text-cyan-950 py-1 px-4 break-keep " href="{{url('/dashboard')}}">Admin Panel</a>
                        </li>
                    @endif
                @endauth
                <li class="mr-3">
                    <a class="inline-block text-white no-underline hover:text-cyan-950 py-2 px-4" href="{{ url('/showProjects') }}">Archive</a>
                </li>
                @auth
                    <li class="mr-3">
                        <a class="inline-block text-white no-underline hover:text-cyan-950 py-2 px-4" href="{{ url('/proposals') }}">Proposal</a>
                    </li>
                @endauth
                @auth
                    @if(Auth::user()->user_type!='admin')
                    <li class="mr-3">
                    <a class="inline-block text-white no-underline hover:text-cyan-950 py-2 px-4" href="{{ url('/contact') }}">Contact</a>
                </li>
                @endif
                @endauth

                @guest
                <li class="mr-3">
                    <a class="inline-block text-white no-underline hover:text-cyan-950 py-2 px-4" href="{{ url('/contact') }}">Contact</a>
                </li>
                @endguest
              
                @if (Route::has('login'))
                @auth
                <div class="md:hidden lg:hidden w-9/12 inline-block  text-white no-underline text-opacity-90 border-opacity-20  font-bold border-gray-200 border-t-2 "><i class="fa fa-user text-white pr-1" aria-hidden="true"></i> {{ Auth::user()->name }} :</div>
                
                <li class=" md:hidden lg:hidden mr-2">
                <a href="{{ route('user.fav') }}" class="inline-block text-white opacity-75 no-underline hover:text-cyan-950 py-2 px-4   "><i class="fa fa-star pr-1" aria-hidden="true"></i>Favorites list</a>
                </li>

                <li class=" md:hidden lg:hidden mr-2">
                <a href="{{ route('profile.show') }}" class="inline-block text-white opacity-75 no-underline hover:text-cyan-950 py-2 px-4  "><i class="fa fa-pencil-square-o text-white pr-0.5" aria-hidden="true"></i>Change password</a>
                </li>

                <li class="md:hidden lg:hidden mr-3">
                <form method="POST" action="{{ route('logout') }}">
                     @csrf
                    <a href="{{ route('logout') }}" onclick="event.preventDefault(); this.closest('form').submit();" class=" inline-block text-white opacity-75 no-underline hover:text-cyan-950 py-2 px-4 "><i class="fa fa-sign-out text-white pr-0.5" aria-hidden="true"></i>Log out</a>
                    </form></li>
                @else
                <div class="md:hidden lg:hidden w-9/12 inline-block  text-white no-underline text-opacity-90 border-opacity-20  font-bold border-gray-200 border-t-2 ">My Account:</div>
                <li class="md:hidden lg:hidden  mr-3">
                <a class="nline-block text-white opacity-75 no-underline hover:text-cyan-950 py-2 px-4 " href="{{ route('login') }}"><i class="fa fa-sign-in text-white pr-0.5" aria-hidden="true"></i>Login</a>
                </li> 
                @endauth
              
              @endif

              

               
              
            </ul>
        </div>
      </div>
      <hr class="border-b border-gray-100 opacity-25 my-0 py-0" />
    </nav>
    <div style="margin-bottom: 90px;"></div>
    @if(Session::has('success'))
        <div class="alert alert-success alert-dismissible show">
            {{ session('success') }}
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    @endif
    @if(Session::has('error'))
        <div class="alert alert-danger alert-dismissible show">
            {{ session('error') }}
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    @endif