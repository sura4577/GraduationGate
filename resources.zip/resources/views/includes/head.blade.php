<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <link rel="icon" href="{{asset('images/favicon.png')}}" type="image/x-icon">
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <meta name="description" content="Graduation Gate is a customized graduation projects management system (GPMS) designed to streamline and enhance the management of graduation projects for students and faculty members. Offering features like electronic proposal submission, group formation, and a comprehensive archive system, our platform aims to simplify the complexities of the graduation project process. Enjoy a centralized platform for project collaboration, documentation, and communication, ensuring a smoother and more organized journey throughout your graduation project semester.">
  <meta http-equiv="X-UA-Compatible" content="ie=edge" />
  <meta name="description" content="Graduation Projects Management System (GPMS)" />
  <title>
  Graduation Gate
  </title>
   <!-- Open Graph meta tags for better social media sharing -->
   <meta property="og:title" content="Grauation Gate">
    <meta property="og:description" content="Graduation Gate is a customized graduation projects management system (GPMS) designed to streamline and enhance the management of graduation projects for students and faculty members. Offering features like electronic proposal submission, group formation, and a comprehensive archive system, our platform aims to simplify the complexities of the graduation project process. Enjoy a centralized platform for project collaboration, documentation, and communication, ensuring a smoother and more organized journey throughout your graduation project semester.">
    <meta property="og:url" content="http://gpms.devproedge.net/">
    <meta property="og:image" content="http://gpms.devproedge.net/">

    <!-- Twitter Card meta tags for better Twitter sharing -->
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="Your Website Title">
    <meta name="twitter:description" content="Graduation Gate is a customized graduation projects management system (GPMS) designed to streamline and enhance the management of graduation projects for students and faculty members. Offering features like electronic proposal submission, group formation, and a comprehensive archive system, our platform aims to simplify the complexities of the graduation project process. Enjoy a centralized platform for project collaboration, documentation, and communication, ensuring a smoother and more organized journey throughout your graduation project semester.">
    <meta name="twitter:image" content="http://gpms.devproedge.net/">

    <!-- Additional meta tags for search engines -->
    <meta name="robots" content="index, follow">
  <!-- Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Varela+Round&display=swap" rel="stylesheet">
        <link rel="stylesheet"href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <!-- Css Files -->
  <link rel="stylesheet" href="css/font-awesome.min.css" />
  <link rel="stylesheet" href="output.css" />
  <link rel="stylesheet" href="https://unpkg.com/tailwindcss@2.2.19/dist/tailwind.min.css" />
  <link rel="stylesheet" href="https://unpkg.com/tailwindcss@2.2.19/dist/tailwind.min.css" />
  <!--Replace with your tailwind.css once created-->
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:400,700" rel="stylesheet" />
  <!-- Define your gradient here - use online tools to find a gradient matching your branding-->
  <script src="https://cdn.tailwindcss.com"></script>
  <script src="https://cdn.jsdelivr.net/npm/alpinejs@2.8.2/dist/alpine.js" defer></script>

  <style>
    .gradient {
      background: linear-gradient(90deg, #005299 0%, #0891B2 100%);
    }
  </style>
</head>