<footer class="bg-[#F0F3F4] mt-auto">
  <div class="w-full mx-auto max-w-screen-xl p-4 md:flex md:items-center md:justify-between">
      <span class="text-sm text-gray-500 sm:text-center dark:text-gray-400">© 2023 <a href="/" class="hover:underline">Graduation Gate</a>. All Rights Reserved.
    </span>
    <ul class="flex flex-wrap items-center mt-3 text-sm font-medium text-gray-500 dark:text-gray-400 sm:mt-0">
        <li>
            <a class="hover:underline me-4 md:me-6" data-modal-target="default-a" data-modal-toggle="default-a">About</a>
                <!-- popup for about us  -->
                <div id="default-a" tabindex="-1" aria-hidden="true" class="fixed top-0 left-0 right-0 z-50 hidden w-full p-4 overflow-x-hidden overflow-y-auto md:inset-0 h-[calc(100%-1rem)] max-h-full">
      <div class="relative w-full max-w-2xl max-h-full">

        <div class="relative bg-white rounded-lg shadow">

            <div class="flex items-start justify-between p-4 border-b rounded-t ">
              <h3 class="text-xl font-semibold text-gray-900 ">
              About us</h3>
              <button type="button" class="text-gray-400 bg-transparent hover:bg-gray-200 hover:text-gray-900 rounded-lg text-sm w-8 h-8 ml-auto inline-flex justify-center items-center " data-modal-hide="default-a">
                                  <svg class="w-3 h-3" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 14 14">
                                      <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m1 1 6 6m0 0 6 6M7 7l6-6M7 7l-6 6"/>
                                  </svg>
                                  <span class="sr-only">Close modal</span>
                              </button>
            </div>
            <div class=" block p-4 space-y-4">
            <p> Welcome to Graduation Gate, where we have designed this platform to guide College Of Computer individuals through the graduation project phase. Our mission is to provide a seamless experience and comprehensive resources.
              <br>
              <br>
              Designed and developed by Sura Alfowzan, Remaz Aldakhil, and Amjad Abu Shafqa.</p>
            </div>

 
            <div class="w-full flex items-center border-t border-gray-200 py-1 relative overflow-x-auto mb-2">
                <div class="w-full flex justify-end items-center px-4 space-x-2 rounded-b  ">
                <button data-modal-hide="default-a" type="button" class="text-white bg-cyan-950 hover:bg-cyan-950 focus:ring-4 focus:outline-none focus:ring-cyan-950 font-medium rounded-lg text-sm px-5 py-2.5 text-center ">Done</button>
              </div>

        </div>
      </div>
      </div>
        </li>

        <li>
            <a  class="hover:underline me-4 md:me-6" data-modal-target="default-FAQ" data-modal-toggle="default-FAQ">FAQ</a>
                <!-- popup for FAQ -->
                <div id="default-FAQ" tabindex="-1" aria-hidden="true" class="fixed top-0 left-0 right-0 z-50 hidden w-full p-4 overflow-x-hidden overflow-y-auto md:inset-0 h-[calc(100%-1rem)] max-h-full">
      <div class="relative w-full max-w-2xl max-h-full">

        <div class="relative bg-white rounded-lg shadow">

            <div class="flex items-start justify-between p-4 border-b rounded-t ">
              <h3 class="text-xl font-semibold text-gray-900 ">
              FAQ</h3>
              <button type="button" class="text-gray-400 bg-transparent hover:bg-gray-200 hover:text-gray-900 rounded-lg text-sm w-8 h-8 ml-auto inline-flex justify-center items-center " data-modal-hide="default-FAQ">
                                  <svg class="w-3 h-3" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 14 14">
                                      <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m1 1 6 6m0 0 6 6M7 7l6-6M7 7l-6 6"/>
                                  </svg>
                                  <span class="sr-only">Close modal</span>
                              </button>
            </div>
            <div class=" block p-4 space-y-4">
            <p> FAQ</p>
            </div>

 
            <div class="w-full flex items-center border-t border-gray-200 py-1 relative overflow-x-auto  mb-2">
                <div class="w-full flex justify-end items-center px-4 space-x-2 rounded-b  ">
                <button data-modal-hide="default-FAQ" type="button" class="text-white bg-cyan-950 hover:bg-cyan-950 focus:ring-4 focus:outline-none focus:ring-cyan-950 font-medium rounded-lg text-sm px-5 py-2.5 text-center ">Done</button>
              </div>

        </div>
      </div>
      </div>

        </li>
        <li>
            <a href="#" class="hover:underline me-4 md:me-6">Privacy Policy</a>
        </li>
        <li>
            <a href="#" class="hover:underline me-4 md:me-6">Licensing</a>
        </li>
        <li>
            <a  class="hover:underline" data-modal-target="default" data-modal-toggle="default" >Contact</a>
        </li>
    </ul>
    </div>

    

    <!-- popup for contact -->
    <div id="default" tabindex="-1" aria-hidden="true" class="fixed top-0 left-0 right-0 z-50 hidden w-full p-4 overflow-x-hidden overflow-y-auto md:inset-0 h-[calc(100%-1rem)] max-h-full">
      <div class="relative w-full max-w-2xl max-h-full">

        <div class="relative bg-white rounded-lg shadow">

          <div class="flex items-start justify-between p-4 border-b rounded-t ">
            <h3 class="text-xl font-semibold text-gray-900 ">
            Contact Technical Support Team</h3>
            <button type="button" class="text-gray-400 bg-transparent hover:bg-gray-200 hover:text-gray-900 rounded-lg text-sm w-8 h-8 ml-auto inline-flex justify-center items-center " data-modal-hide="default">
                                <svg class="w-3 h-3" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 14 14">
                                    <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m1 1 6 6m0 0 6 6M7 7l6-6M7 7l-6 6"/>
                                </svg>
                                <span class="sr-only">Close modal</span>
                            </button>
          </div>
          <div class=" block p-4 space-y-4">
            <div class="w-full flex flex-warp"> 
          <p class="text-md font-semibold  text-cyan-950 mr-1 ">Contact with </p>
          <a href="mailto:411201802@qu.edu.sa" class="text-blue-500 underline text-cyan-600">Sura Saleh</a>
          </div>

          <div class="w-full flex flex-warp"> 
          <p class="text-md font-semibold  text-cyan-950 mr-1 ">Contact with </p>
          <a href="mailto:411216178@qu.edu.sa" class="text-blue-500 underline text-cyan-600">Amjad Monther </a>
          </div>

          <div class="w-full flex flex-warp"> 
          <p class="text-md font-semibold  text-cyan-950 mr-1 ">Contact with </p>
          <a href="mailto:411202076@qu.edu.sa" class="text-blue-500 underline text-cyan-600">Remaz Suliman</a>
          </div>
            

           
            <div class="w-full flex items-center border-t border-gray-200 py-1 relative overflow-x-auto ">
                <div class="w-full flex justify-end items-center px-4 space-x-2 rounded-b  ">
                <button data-modal-hide="default" type="button" class="text-white bg-cyan-950 hover:bg-cyan-950 focus:ring-4 focus:outline-none focus:ring-cyan-950 font-medium rounded-lg text-sm px-5 py-2.5 text-center ">Done</button>
              </div>
          </div>




        </div>
      </div>
      </div>

   

       <!-- popup for About -->

  </footer>

  <script>
    var scrollpos = window.scrollY;
    var header = document.getElementById("header");
    var navcontent = document.getElementById("nav-content");
    var navaction = document.getElementById("navAction");
    var brandname = document.getElementById("brandname");
    var toToggle = document.querySelectorAll(".toggleColour");

    document.addEventListener("scroll", function() {
      /*Apply classes for slide in bar*/
      scrollpos = window.scrollY;

      if (scrollpos > 10) {
        header.classList.add("bg-[#F0F3F4] ");
        navaction.classList.remove("bg-[#F0F3F4] ");
        navaction.classList.add("gradient");
        navaction.classList.remove("text-gray-800");
        navaction.classList.add("text-white");
        //Use to switch toggleColour colours
        for (var i = 0; i < toToggle.length; i++) {
          toToggle[i].classList.add("text-gray-800");
          toToggle[i].classList.remove("text-white");
        }
        header.classList.add("shadow");
        navcontent.classList.remove("bg-gray-100");
        navcontent.classList.add("bg-[#F0F3F4] ");
      } else {
        header.classList.remove("bg-[#F0F3F4] ");
        navaction.classList.remove("gradient");
        navaction.classList.add("bg-[#F0F3F4] ");
        navaction.classList.remove("text-white");
        navaction.classList.add("text-gray-800");
        //Use to switch toggleColour colours
        for (var i = 0; i < toToggle.length; i++) {
          toToggle[i].classList.add("text-white");
          toToggle[i].classList.remove("text-gray-800");
        }

        header.classList.remove("shadow");
        navcontent.classList.remove("bg-[#F0F3F4] ");
        navcontent.classList.add("bg-gray-100");
      }
    });
  </script>
  <script>
    /*Toggle dropdown list*/
    /*https://gist.github.com/slavapas/593e8e50cf4cc16ac972afcbad4f70c8*/

    var navMenuDiv = document.getElementById("nav-content");
    var navMenu = document.getElementById("nav-toggle");

    document.onclick = check;

    function check(e) {
      var target = (e && e.target) || (event && event.srcElement);

      //Nav Menu
      if (!checkParent(target, navMenuDiv)) {
        // click NOT on the menu
        if (checkParent(target, navMenu)) {
          // click on the link
          if (navMenuDiv.classList.contains("hidden")) {
            navMenuDiv.classList.remove("hidden");
          } else {
            navMenuDiv.classList.add("hidden");
          }
        } else {
          // click both outside link and outside menu, hide menu
          navMenuDiv.classList.add("hidden");
        }
      }
    }

    function checkParent(t, elm) {
      while (t.parentNode) {
        if (t == elm) {
          return true;
        }
        t = t.parentNode;
      }
      return false;
    }
  </script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/flowbite/1.8.1/flowbite.min.js"></script>