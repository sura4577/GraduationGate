@include('includes.head')
    <body id="mainBody" class=" leading-normal tracking-normal bg-[#F0F3F4] leading-normal tracking-normal min-h-screen flex flex-col" >
    <!--Nav-->
    @include('includes.header')
    <hr class="border-b border-gray-100 opacity-25 my-0 py-0" />
   
    <script>
    function classificationsss(val) {
    document.getElementById("classification").value = val;
    document.getElementById("classificationName").innerHTML = val ? val : 'All Classifications'; // Update the displayed text

    document.getElementById("search-form").submit(); // Submit the form directly
}
 
      function yearssss(val) {
    document.getElementById("years").value = val;
    document.getElementById("yearsName").innerHTML = val ? val : 'All Years'; // Update the displayed text

    document.getElementById("search-form").submit(); // Submit the form directly
}

    </script>
<nav class="flex mx-3 mt-2 pb-3 border-b-2  border-stone-300 " aria-label="Breadcrumb">
  <ol class="inline-flex items-center space-x-1 md:space-x-3">
    <li class="inline-flex items-center">
    @auth
      <a href="{{ url('/HomeAsGPC') }}" class="inline-flex items-center text-sm font-medium text-cyan-950  underline  "> 
        Home
      </a>
      @endauth
      @guest
      <a href="{{ url('/') }}" class="inline-flex items-center text-sm font-medium text-cyan-950  underline  "> 
        Home
      </a>
      @endguest

    </li>
    <li aria-current="page">
      <div class="flex items-center">
        <svg class="w-3 h-3 text-[#005299] mx-1" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 6 10">
          <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m1 9 4-4-4-4"/>
        </svg>
        <span class="ml-1 text-sm font-medium text-[#0891B2] md:ml-2 ">Archive</span>
      </div>
    </li>
  </ol>
</nav>




    <div class="flex w-full flex-wrap items-center  justify-center text-xs md:text-sm flex-grow">
      <div class="md:w-full w-11/12  justify-center flex my-3 mx-auto ">        
        <form id="search-form" action="{{url('/searchProjects')}}" method="post">
           @csrf
            <div class="flex w-full">
                <label for="search-dropdown" class="mb-2 text-xs md:text-sm md:font-medium text-gray-900 "></label>
                <button id="dropdown-button1" data-dropdown-toggle="dropdown" class=" classificationBtn flex-shrink-0 z-10 inline-flex items-center py-2.5 px-4 text-xs md:text-sm font-medium text-center text-gray-900 bg-gray-100 border border-gray-300 rounded-l-lg hover:bg-gray-200 " type="button"> <span id="classificationName">
                  
                  @if(Request::get('classification') )
                    {{Request::get('classification')}}
                  @else
                  All classifications
                  @endif
                </span> <svg class="w-2.5 h-2.5 md:w-1.5 md:h-1.5 ml-1.5" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 10 6">
            <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m1 1 4 4 4-4"/>
          </svg></button>
                <div id="dropdown" class="z-10 hidden bg-white divide-y divide-gray-100  shadow w-64 md:w-96">
                    <ul class="py-2 px-4 text-xs md:text-sm text-gray-700 " aria-labelledby="dropdown-button1">

                      @php
                        $classifications = DB::table('projects')->groupBy('research_specialization')->get();
                      @endphp
                      @foreach ($classifications as $classification)
                      <!-- <li>
                          <button type="button" class="inline-flex w-full px-10  py-2 hover:bg-gray-100" onclick="classificationsss('{{$classification->research_specialization}}')">{{$classification->research_specialization}}</button>
                      </li> -->
                      @endforeach
                      <li>
                          <button type="button" onclick="classificationsss('')" class="inline-flex w-full px-10 py-2 hover:bg-gray-100">All</button>
                      </li>                
                      <li>
                          <button type="button" class="inline-flex w-full px-10  py-2 hover:bg-gray-100 " onclick="classificationsss('Artificial intelligence')">Artificial Intelligence</button>
                      </li>
                      <li>
                          <button type="button" class="inline-flex w-full px-10  py-2 hover:bg-gray-100 " onclick="classificationsss('Cybersecurity')">Cybersecurity</button>
                      </li>
                      <li>
                          <button type="button" class="inline-flex w-full px-10  py-2 hover:bg-gray-100 " onclick="classificationsss('Mobile applications')">Mobile Applications</button>
                      </li>
                      <li>
                          <button type="button" class="inline-flex w-full px-10  py-2 hover:bg-gray-100 " onclick="classificationsss('IOT')">Internet Of Things</button>
                      </li>
                      <li>
                          <button type="button" class="inline-flex w-full px-10  py-2 hover:bg-gray-100 " onclick="classificationsss('Automated systems')">Automated Systems</button>
                      </li>
                      <li>
                          <button type="button" class="inline-flex w-full px-10  py-2 hover:bg-gray-100 " onclick="classificationsss('Classification methods')">Classification Methods</button>
                      </li>
                    </ul>
                </div>
                <input type="hidden" name="classification" value="{{ Request::get('classification') }}" id="classification">
                <input type="hidden" name="years" id="years" value="{{ Request::get('years')}}">
                
                <label for="search-dropdown" class="mb-2 text-xs md:text-sm md:font-medium text-gray-900 sr-only ">Your Email</label>
                <button id="dropdown-button" data-dropdown-toggle="dropdown1" class="yearsBtn flex-shrink-0 z-10 inline-flex items-center py-2.5 px-2 text-xs md:text-sm font-medium text-center text-gray-900 bg-gray-100 border border-gray-300  hover:bg-gray-200 " type="button"> <span id="yearsName">
                @if(Request::get('years') )
                  {{Request::get('years')}}
                @else
                  All Years
                @endif
                </span> <svg class="w-2.5 h-2.5 md:w-1.5 md:h-1.5 ml-1.5" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 10 6">
            <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m1 1 4 4 4-4"/>
          </svg></button>
                <div id="dropdown1" class="z-10 hidden bg-white divide-y divide-gray-100 rounded-lg shadow w-64 md:w-96  ">
                    <ul class="py-2 px-2 text-xs md:text-sm text-gray-700 " aria-labelledby="dropdown-button">
                    <li>
                        <button type="button" onclick="yearssss('')" class="inline-flex w-full px-10 py-2 hover:bg-gray-100">All </button>
                    </li>
                    <li>
                        <button type="button" onclick="yearssss('2023')" class="inline-flex w-full px-10  py-2 hover:bg-gray-100 ">2023</button>
                    </li>
                    <li>
                        <button type="button" onclick="yearssss('2022')" class="inline-flex w-full px-10  py-2 hover:bg-gray-100 ">2022</button>
                    </li>
                    <li>
                        <button type="button" onclick="yearssss('2021')" class="inline-flex w-full px-10  py-2 hover:bg-gray-100 ">2021</button>
                    </li>
                    <li>
                        <button type="button" onclick="yearssss('2020')" class="inline-flex w-full px-10  py-2 hover:bg-gray-100 ">2020</button>
                    </li>
                    <li>
                        <button type="button"  onclick="yearssss('2019')" class="inline-flex w-full px-10  py-2 hover:bg-gray-100 ">2019</button>
                    </li>
                    </ul>
                    
                </div>
                
                <div class="relative w-full ">
                    <input name="searchProject" type="search" id="search-dropdown" class="block p-2.5  md:pr-96 pr-24  w-full   text-xs md:text-sm text-gray-900 bg-gray-50 rounded-r-lg border-l-gray-50 border-l-2 border border-gray-300 px-100" placeholder="Search .." value="{{ Request::get('searchProject') }}" >
                    <button type="submit" class="absolute top-0 right-0 p-2.5 text-xs md:text-sm font-medium h-full text-white bg-[#0891B2]  rounded-r-lg border border-bg-[#0891B2]  "> 
                        <svg class="w-900 h-4" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 20 20">
                            <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m19 19-4-4m0-7A7 7 0 1 1 1 8a7 7 0 0 1 14 0Z"/>
                        </svg>
                        <span class="sr-only ">Search</span>
                    </button>
                </div>
            </div>
        </form>
      </div>
    

   </div>

 


    <div class=" flex flex-wrap justify-center text-center text-sm md:w-full w-11/12 mx-auto ">
      
   <div  class=" w-full md:w-10/12 flex items-center">
              <div class="w-8/12 md:w-10/12 ">
                <h1 class="text-left text-xl  md:ml-8"> Archives :</h1> 
              </div>
              @if(Auth::check())
              @if(auth()->user()->user_type == 'admin')
                  <div class="justify-center p-1 mx-1 ">
                    <a href="{{ route('notApprovedProjects') }}">
                        <button  class="w-full md:w-10/12 p-1 gradient border-0 rounded-sm mx-2 md:mx-4 items-center hover:bg-cyan-600 hover:cursor-pointer"><i class="fa fa-Upload Project text-white text-xs" aria-hidden="true"> Upload Projects</i></button></a>
                  </div>
                  @endif
                  @endif
              </div>

      <!-- Card -->
      @foreach($projects as $project)
        <div class="md:w-80 p-6 bg-white border border-gray-200 rounded-lg shadow m-2 hover:bg-opacity-50 content">
          <div class="md:h-36"> 
              <h5 class="mb-2 text-lg md:text-md font-bold tracking-tight text-gray-900 line-clamp-2">{{$project->name}}</h5>
          <p class="mb-3 font-normal text-gray-700  text-left line-clamp-4 ">
            {{$project->narration}}
          </p>
          </div>
          <div class="w-full flex flex-wrap items-center border-t-2 border-black-100 border-solid">
            <!-- <button data-modal-target="projectModal{{$project->id}}" data-modal-toggle="projectModal{{$project->id}}" class="float-left  px-3 py-2 text-sm font-medium text-center text-white gradient rounded-full  hover:bg-cyan-600 mt-2">View</button> -->
            <a href="{{ route('readMore', ['id' => $project->id]) }}" class="float-left  px-3 py-2 text-sm font-medium text-center text-white gradient rounded-full  hover:bg-cyan-600 mt-2">Read more</a>
            <p class="float-right text-stone-600 mt-2  text-xs text-end md:ml-20 ml-36 " ><b>
              
  
              {{ \Carbon\Carbon::parse($project->uploade_date)->format('d/m/Y')}}
            
            
            </b></p>
          </div>
        </div>

        @endforeach

        
        
        </div>
        <!-- <div class="pagination-links">
    {{ $projects->appends(request()->query())->links() }}
</div> -->
        <!-- <nav>
    {{ $projects->links() }}
</nav>

        <nav class="w-full  flex justify-cnter items-center space-x-px rounded-md shadow-sm" >
  <ul class="pagination flex  justify-cnter">
    {{ $projects->links() }}
  </ul>
</nav>
         -->

         @php
    $queryParams = [];

    if (Request::get('years')) {
        $queryParams['years'] = Request::get('years');
    }

    if (Request::get('classification')) {
        $queryParams['classification'] = Request::get('classification');
    }

    if (Request::get('searchProject')) {
        $queryParams['searchProject'] = Request::get('searchProject');
    }

    $query = http_build_query($queryParams);
@endphp
<div class="w-full flex items-center justify-center px-4 py-3 sm:px-6">
    <div class="flex flex-1 justify-between sm:hidden">
        <a href="{{ $projects->previousPageUrl() . '&' . $query }}" class="relative inline-flex items-center no-underline rounded-md border border-gray-300 bg-[#F0F3F4] px-4 py-2 text-sm font-medium text-cyan-950 underline hover:bg-gray-50">
            <i class="fa fa-angle-left mr-1 " aria-hidden="true"></i> Previous
        </a>
        <a href="{{ $projects->nextPageUrl() . '&' . $query }}" class="relative ml-3 inline-flex items-center no-underline rounded-md border border-gray-300 bg-[#F0F3F4] px-4 py-2 text-sm font-medium text-cyan-950 underline hover:bg-gray-50 ">
            Next<i class="fa fa-angle-right ml-1" aria-hidden="true"></i>
        </a>
    </div>
    <div class="hidden sm:flex sm:flex-1 sm:items-center sm:justify-center">
        <a href="{{ $projects->previousPageUrl() . '&' . $query }}" class="relative inline-flex items-center bg-[#F0F3F4] rounded-l-md px-2 py-2 text-gray-400 ring-1 ring-inset ring-gray-300 hover:bg-gray-50 focus:z-20 ">
            <span class="sr-only">Previous</span>
            <svg class="h-5 w-5" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                <path fill-rule="evenodd" d="M12.79 5.23a.75.75 0 01-.02 1.06L8.832 10l3.938 3.71a.75.75 0 11-1.04 1.08l-4.5-4.25a.75.75 0 010-1.08l4.5-4.25a.75.75 0 011.06.02z" clip-rule="evenodd" />
            </svg>
        </a>
        <nav class="Pagination isolate inline-flex -space-x-px rounded-md shadow-sm" aria-label="Pagination">
            @foreach ($projects->appends(request()->query())->links()->elements[0] as $link)
                <a href="{{ $link . '&' . $query }}" aria-current="page" class="relative z-10 inline-flex items-center gradient px-4 py-2 text-sm font-semibold text-white @if ($link == $projects->currentPage()) bg-gray-800 @else hover-bg-gray-700 @endif">
                    {{ $loop->iteration }}
                </a>
            @endforeach
        </nav>
        <a href="{{ $projects->nextPageUrl() . '&' . $query }}" class="relative inline-flex items-center bg-[#F0F3F4] rounded-r-md px-2 py-2 text-gray-400 ring-1 ring-inset ring-gray-300 hover:bg-gray-50 ">
            <span class="sr-only">Next</span>
            <svg class="h-5 w-5" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                <path fill-rule="evenodd" d="M7.21 14.77a.75.75 0 01.02-1.06L11.168 10 7.23 6.29a.75.75 0 111.04-1.08l4.5 4.25a.75.75 0 010 1.08l-4.5 4.25a.75.75 0 01-1.06-.02z" clip-rule="evenodd" />
            </svg>
        </a>
    </div>
</div>


    

  </container>
  @include('includes.footer')

  
  <script>
    var scrollpos = window.scrollY;
    var header = document.getElementById("header");
    var navcontent = document.getElementById("nav-content");
    var navaction = document.getElementById("navAction");
    var brandname = document.getElementById("brandname");
    var toToggle = document.querySelectorAll(".toggleColour");

    document.addEventListener("scroll", function() {
      /*Apply classes for slide in bar*/
      scrollpos = window.scrollY;

      if (scrollpos > 10) {
        header.classList.add("bg-[#F0F3F4] ");
        navaction.classList.remove("bg-[#F0F3F4] ");
        navaction.classList.add("gradient");
        navaction.classList.remove("text-gray-800");
        navaction.classList.add("text-white");
        //Use to switch toggleColour colours
        for (var i = 0; i < toToggle.length; i++) {
          toToggle[i].classList.add("text-gray-800");
          toToggle[i].classList.remove("text-white");
        }
        header.classList.add("shadow");
        navcontent.classList.remove("bg-gray-100");
        navcontent.classList.add("bg-[#F0F3F4] ");
      } else {
        header.classList.remove("bg-[#F0F3F4] ");
        navaction.classList.remove("gradient");
        navaction.classList.add("bg-[#F0F3F4] ");
        navaction.classList.remove("text-white");
        navaction.classList.add("text-gray-800");
        //Use to switch toggleColour colours
        for (var i = 0; i < toToggle.length; i++) {
          toToggle[i].classList.add("text-white");
          toToggle[i].classList.remove("text-gray-800");
        }

        header.classList.remove("shadow");
        navcontent.classList.remove("bg-[#F0F3F4] ");
        navcontent.classList.add("bg-gray-100");
      }
    });
  </script>
  <script>
    /*Toggle dropdown list*/
    /*https://gist.github.com/slavapas/593e8e50cf4cc16ac972afcbad4f70c8*/

    var navMenuDiv = document.getElementById("nav-content");
    var navMenu = document.getElementById("nav-toggle");

    document.onclick = check;

    function check(e) {
      var target = (e && e.target) || (event && event.srcElement);

      //Nav Menu
      if (!checkParent(target, navMenuDiv)) {
        // click NOT on the menu
        if (checkParent(target, navMenu)) {
          // click on the link
          if (navMenuDiv.classList.contains("hidden")) {
            navMenuDiv.classList.remove("hidden");
          } else {
            navMenuDiv.classList.add("hidden");
          }
        } else {
          // click both outside link and outside menu, hide menu
          navMenuDiv.classList.add("hidden");
        }
      }
    }

    function checkParent(t, elm) {
      while (t.parentNode) {
        if (t == elm) {
          return true;
        }
        t = t.parentNode;
      }
      return false;
    }
  </script>
  


  <script src="https://cdnjs.cloudflare.com/ajax/libs/flowbite/1.8.1/flowbite.min.js"></script>
  </body>
  </html>

