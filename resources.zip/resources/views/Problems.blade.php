@include('includes.head')
<body  class=" leading-normal tracking-normal bg-[#F0F3F4] min-h-screen flex flex-col " >
         <!--Nav-->
         @include('includes.header')
         <style>
        .tooltip {
            @apply relative cursor-pointer;
        }

        .tooltip .tooltip-text {
            @apply invisible opacity-0 transition-all duration-300 ease-in-out absolute bottom-[-125%] left-1/2 transform-translate-x-[-50%] bg-gray-800 text-white p-2 rounded shadow z-10;
        }

        .tooltip:hover .tooltip-text {
            @apply visible opacity-100;
        }
    </style>
    
<nav class="flex mb-4 mx-3 my-2" aria-label="Breadcrumb">
  <ol class="inline-flex items-center space-x-1 md:space-x-3">
    <li class="inline-flex items-center">
    @auth
      <a href="{{ url('/HomeAsGPC') }}" class="inline-flex items-center text-sm font-medium text-cyan-950  underline  "> 
        Home
      </a>
      @endauth
      @guest
      <a href="{{ url('/') }}" class="inline-flex items-center text-sm font-medium text-cyan-950  underline  "> 
        Home
      </a>
      @endguest
    </li>
    <li aria-current="page">
      <div class="flex items-center">
        <svg class="w-3 h-3 text-[#005299] mx-1" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 6 10">
          <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m1 9 4-4-4-4"/>
        </svg>
        <span class="ml-1 text-sm font-medium text-[#0891B2] md:ml-2 ">Contact GPC</span>
      </div>
    </li>
  </ol>
</nav>



          <!-- Problem section -->
        <div class=" mx-auto w-11/12 md:w-3/5  p-3  bg-white rounded-md  text-sm flex-grow">
        <div x-data="{ tooltip: false }" @mouseenter="tooltip = true" @mouseleave="tooltip = false" class="tooltip">
          <h1 class="text-base md:text-2xl text-center p-b-4 txet-cyan-950 border-b-2 border-b-stone-200 ">Contact GPC </h1>
          <div x-show="tooltip" x-cloak class="tooltip-text text-center text-cyan-600 font-bold">
          Graduation Project Committee </div>
    </div>
          <form action="{{url('addProblems')}}" method="post" enctype="multipart/form-data">
            @csrf
            <div class="block md:flex md:flex-wrap my-0 md:py-2 px-4 md:px-4 justify-center">
              <div class=" justify-center items-center w-full p-b-1 my-1 mx-auto">
                <label class="w-full text-cyan-950 text-md m-1  " for="pname"> Subject </label>
                <input class="block p-2.5 w-full text-sm text-gray-900 bg-gray-50 rounded-lg border border-gray-300" type="text"
                        id="PSubject"
                        name="problem_subject"
                        placeholder="Enter problem subject" required/>
              </div>
              <div class=" justify-center items-center w-full p-b-1 my-1 mx-auto">
                  <label class="w-full text-cyan-950 text-md m-1" for="ressp">Name</label>
                  <input class="block p-2.5 w-full text-sm text-gray-900 bg-gray-50 rounded-lg border border-gray-300" type="text"
                          id="Name"
                          name="name"
                          placeholder="Enter Your name " required/>
                </div>
                <div class="justify-center items-center w-full p-b-1 my-1 mx-auto">
    <label class="w-full text-cyan-950 text-md m-1" for="email">Email</label>
    <input class="block p-2.5 w-full text-sm text-gray-900 bg-gray-50 rounded-lg border border-gray-300" type="email"
        id="email"
        name="email"
        placeholder="Enter your email"
        value="{{ auth()->user() ? auth()->user()->email : '' }}" 
        required readonly />
</div>

                <div class=" justify-center items-center w-full p-b-1 my-1 mx-auto">
                  <label class="w-full text-cyan-950 text-md m-1   " for="stname">Description of the problem</label>
                  <textarea id="message" rows="10 " class="block p-2.5 w-full text-sm text-gray-900 bg-gray-50 rounded-lg border border-gray-300 " placeholder="Enter description of the problem " name="narration" required></textarea>
                </div>

                <div class="text-center overflow-hidden w-full  my-3 mx-auto text-md rounded-sm text-white  ">
                  <button class="w-5/12 md:w-3/12  my-2 p-1 text-md rounded-sm text-white bg-cyan-950 hover:bg-stone-300 hover:text-cyan-950 float-right">Report Problem</button>
                </div>
                
          </div>
        </div>
      


        </container>
        @include('includes.footer')

        
  <script>
    var scrollpos = window.scrollY;
    var header = document.getElementById("header");
    var navcontent = document.getElementById("nav-content");
    var navaction = document.getElementById("navAction");
    var brandname = document.getElementById("brandname");
    var toToggle = document.querySelectorAll(".toggleColour");

    document.addEventListener("scroll", function() {
      /*Apply classes for slide in bar*/
      scrollpos = window.scrollY;

      if (scrollpos > 10) {
        header.classList.add("bg-[#F0F3F4] ");
        navaction.classList.remove("bg-[#F0F3F4] ");
        navaction.classList.add("gradient");
        navaction.classList.remove("text-gray-800");
        navaction.classList.add("text-white");
        //Use to switch toggleColour colours
        for (var i = 0; i < toToggle.length; i++) {
          toToggle[i].classList.add("text-gray-800");
          toToggle[i].classList.remove("text-white");
        }
        header.classList.add("shadow");
        navcontent.classList.remove("bg-gray-100");
        navcontent.classList.add("bg-[#F0F3F4] ");
      } else {
        header.classList.remove("bg-[#F0F3F4] ");
        navaction.classList.remove("gradient");
        navaction.classList.add("bg-[#F0F3F4] ");
        navaction.classList.remove("text-white");
        navaction.classList.add("text-gray-800");
        //Use to switch toggleColour colours
        for (var i = 0; i < toToggle.length; i++) {
          toToggle[i].classList.add("text-white");
          toToggle[i].classList.remove("text-gray-800");
        }

        header.classList.remove("shadow");
        navcontent.classList.remove("bg-[#F0F3F4] ");
        navcontent.classList.add("bg-gray-100");
      }
    });
  </script>
  <script>
    /*Toggle dropdown list*/
    /*https://gist.github.com/slavapas/593e8e50cf4cc16ac972afcbad4f70c8*/

    var navMenuDiv = document.getElementById("nav-content");
    var navMenu = document.getElementById("nav-toggle");

    document.onclick = check;

    function check(e) {
      var target = (e && e.target) || (event && event.srcElement);

      //Nav Menu
      if (!checkParent(target, navMenuDiv)) {
        // click NOT on the menu
        if (checkParent(target, navMenu)) {
          // click on the link
          if (navMenuDiv.classList.contains("hidden")) {
            navMenuDiv.classList.remove("hidden");
          } else {
            navMenuDiv.classList.add("hidden");
          }
        } else {
          // click both outside link and outside menu, hide menu
          navMenuDiv.classList.add("hidden");
        }
      }
    }

    function checkParent(t, elm) {
      while (t.parentNode) {
        if (t == elm) {
          return true;
        }
        t = t.parentNode;
      }
      return false;
    }
  </script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/flowbite/1.8.1/flowbite.min.js"></script>

    </body><!-- End Body -->
</html>
