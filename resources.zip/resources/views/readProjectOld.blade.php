<!DOCTYPE html>
<html lang="en" class=" " >
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <meta http-equiv="X-UA-Compatible" content="ie=edge" />
        <title>Graduation Gate</title>
        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Varela+Round&display=swap" rel="stylesheet">
        <!-- Css Files -->
        <link rel="stylesheet" href="css/font-awesome.min.css" />
        <link rel="stylesheet" href="output.css" />
        <link rel="stylesheet" href="https://unpkg.com/tailwindcss@2.2.19/dist/tailwind.min.css"/>
    <!--Replace with your tailwind.css once created-->
    <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:400,700" rel="stylesheet" />
    <!-- Define your gradient here - use online tools to find a gradient matching your branding-->
        <script src="https://cdn.tailwindcss.com"></script>
        <style>
      .gradient {
        background: linear-gradient(30deg, #005299 0%, #0891B2 100%);
      }
    </style>

    </head><!-- End Head -->
    <body  class=" leading-normal tracking-normal bg-[#F0F3F4] " >
         <!--Nav-->
         @include('includes.header')
    <script>
      var scrollpos = window.scrollY;
      var header = document.getElementById("header");
      var navcontent = document.getElementById("nav-content");
      var navaction = document.getElementById("navAction");
      var brandname = document.getElementById("brandname");
      var toToggle = document.querySelectorAll(".toggleColour");

      document.addEventListener("scroll", function () {
        /*Apply classes for slide in bar*/
        scrollpos = window.scrollY;

        if (scrollpos > 10) {
          header.classList.add("bg-[#F0F3F4] ");
          navaction.classList.remove("bg-[#F0F3F4] ");
          navaction.classList.add("gradient");
          navaction.classList.remove("text-gray-800");
          navaction.classList.add("text-white");
          //Use to switch toggleColour colours
          for (var i = 0; i < toToggle.length; i++) {
            toToggle[i].classList.add("text-gray-800");
            toToggle[i].classList.remove("text-white");
          }
          header.classList.add("shadow");
          navcontent.classList.remove("bg-gray-100");
          navcontent.classList.add("bg-[#F0F3F4] ");
        } else {
          header.classList.remove("bg-[#F0F3F4] ");
          navaction.classList.remove("gradient");
          navaction.classList.add("bg-[#F0F3F4] ");
          navaction.classList.remove("text-white");
          navaction.classList.add("text-gray-800");
          //Use to switch toggleColour colours
          for (var i = 0; i < toToggle.length; i++) {
            toToggle[i].classList.add("text-white");
            toToggle[i].classList.remove("text-gray-800");
          }

          header.classList.remove("shadow");
          navcontent.classList.remove("bg-[#F0F3F4] ");
          navcontent.classList.add("bg-gray-100");
        }
      });
    </script>
    <script>
      /*Toggle dropdown list*/
      /*https://gist.github.com/slavapas/593e8e50cf4cc16ac972afcbad4f70c8*/

      var navMenuDiv = document.getElementById("nav-content");
      var navMenu = document.getElementById("nav-toggle");

      document.onclick = check;
      function check(e) {
        var target = (e && e.target) || (event && event.srcElement);

        //Nav Menu
        if (!checkParent(target, navMenuDiv)) {
          // click NOT on the menu
          if (checkParent(target, navMenu)) {
            // click on the link
            if (navMenuDiv.classList.contains("hidden")) {
              navMenuDiv.classList.remove("hidden");
            } else {
              navMenuDiv.classList.add("hidden");
            }
          } else {
            // click both outside link and outside menu, hide menu
            navMenuDiv.classList.add("hidden");
          }
        }
      }
      function checkParent(t, elm) {
        while (t.parentNode) {
          if (t == elm) {
            return true;
          }
          t = t.parentNode;
        }
        return false;
      }
    </script>
<nav class="flex mx-3 mt-2 pb-3 border-b-2  border-stone-300 " aria-label="Breadcrumb">
  <ol class="inline-flex items-center space-x-1 md:space-x-3">
    <li class="inline-flex items-center">
      <a href="Home.html" class="inline-flex items-center text-sm font-medium text-gray-700 "> 
        Home
      </a>
    </li>
    <li aria-current="page">
      <div class="flex items-center">
        <svg class="w-3 h-3 text-gray-400 mx-1" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 6 10">
          <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m1 9 4-4-4-4"/>
        </svg>
        <span class="ml-1 text-sm font-medium text-gray-500 md:ml-2 ">Projects</span>
      </div>
    </li>
  </ol>
</nav>


@section('content')

    <!-- Content Header (Page header) -->
<div class=" flex shadow-md sm:rounded-lg border-t-2 border-stone-300 text-sm">
  <div  class="w-full flex items-center ">
    <div class="w-5/12 md:w-9/12  p-2 flex items:center mb-2">
      <h1 class="text-left md:text-xl text-lg  "> {{ __('Proposals') }} </h1> 
    </div>

    <div class="w-3/12 md:w-2/12 justify-center m-1 md:m-0">
      <a href="{{ url('/proposals') }}">
        <button  class="w-full md:w-11/12  md:px-1 py-2  border-0 rounded-sm mx-2 md:mx-1 items-center gradient  hover:bg-cyan-600 hover:cursor-pointer text-white text-xs ">Browse Proposal</button></a>
    </div>

    <div class="w-3/12 md:w-2/12 justify-center md:mr-6">
      <a href="{{url('/UploadProposal')}}">
        <button  class="w-full md:w-11/12  md:px-1 py-2  border-0 rounded-sm mx-2 md:mx-1 items-center gradient  hover:bg-cyan-600 hover:cursor-pointer text-white text-xs "><i class="fa fa-plus text-white  px-1 " aria-hidden="true"></i>Add purposal</button></a>
    </div>
  </div>
</div>
    <!-- /.content-header -->

    <!-- Main content -->
    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        @if(Session::has('success'))
                            <div class="alert alert-success alert-dismissible show">
                                {{ session('success') }}
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                        @endif
                        @if(Session::has('error'))
                            <div class="alert alert-danger alert-dismissible show">
                                {{ session('error') }}
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                        @endif

                        <div class="overflow-auto rounded-lg shadow hidden md:block md:mx-2 text-sm">
                            <table class="table bg-gray-50 border-b-2 border-gray-200" >
                                <thead class="bg-gray-50 border-b-2 border-gray-200">
                                    <tr>
                                        <th class="w-1/12 text-sm font-semibold tracking-wide text-center">Sr</th>
                                        <th class="w-2/12 text-sm font-semibold tracking-wide text-center">Title</th>
                                        <th class="w-1/12 text-sm font-semibold tracking-wide text-center">Superviser</th>
                                        <th class="w-1/12 text-sm font-semibold tracking-wide text-center">Speciealization</th>
                                        <th class="w-8/12 text-sm font-semibold tracking-wide text-center">Proposal</th>
                                        <th class="w-2/12 text-sm font-semibold tracking-wide text-center">Action</th>
                                    </tr>
                                </thead>
                                <tbody class="divide-y divide-gray-100">
                                    @foreach($proposals as $proposal)
                                        <tr class="bg-white">
                                           <td class="p-3 text-sm text-gray-700 whitespace-nowrap text-center">{{$loop->iteration}}</td>
                                           <td class="p-3 text-sm text-gray-700 whitespace-nowrap text-center">{{$proposal->title}}</td>
                                           <td class="p-3 text-sm text-gray-700 whitespace-nowrap text-center">{{$proposal->supervisor_name}}</td>
                                           <td class="p-3 text-sm text-gray-700 whitespace-nowrap text-center">{{$proposal->research_specialization}}</td> 
                                           <td class="p-3 text-sm text-gray-700 whitespace-wrap ">{{$proposal->proposal}}</td> 
                                           <td  class="flex flex-warp justfiy-center items-centter">
                                                <a onclick="return confirm('Do You Want To approve Proposal')" href="{{ route('approveProposal',['id'=>$proposal->id]) }}"class="btn btn-primary p-2 m-1 border-0 rounded-sm  bg-stone-200 hover:bg-cyan-950  hover:opacity-3 text-green-600">Approve</a>
                                                <a onclick="return confirm('Do You Want To Reject Proposal')" href="{{ route('rejectProposal',['id'=>$proposal->id]) }}"class="btn btn-danger p-2 m-1 border-0 rounded-sm  bg-stone-200 hover:bg-cyan-950  hover:opacity-3 text-red-600">Reject</a>
                                           </td> 
                                        </tr>
                                    @endforeach
                                </tbody>
                            </table>
                            {{$proposals}}
                        </div>
                        <!--in smail screen --> 
              <div class="grid grid-cols-1 sm:grid-cols-2 gap-4 md:hidden ">
              @foreach($proposals as $proposal)
                <div class="bg-white space-y-3 p-4 rounded-lg shadow ">
                  <div class="w-full flex items-center space-x-2 text-sm">
                    <div class="w-6/12 ">
                      <a href="#" class="text-cyan-950 font-bold ">{{$proposal->title}}</a>
                    </div>
                    <div class="w-6/12 text-gray-500">{{$proposal->supervisor_name}}</div>
                  </div>
                  <div class="text-sm text-gray-700">
                  {{$proposal->research_specialization}}                  </div>
                  <div class="text-sm text-gray-700 border-b-2 border-gray-200 pb-2">
                  {{$proposal->proposal}}
                  </div>
                  <div cliss="w-full flex flex-warp float-right ">
                    <a onclick="return confirm('Do You Want To approve Proposal')" href="{{ route('approveProposal',['id'=>$proposal->id]) }}"class="btn btn-primary p-2 m-1 border-0 rounded-sm  bg-stone-200 hover:bg-cyan-950  hover:opacity-3 text-green-600 float-right text-sm ">Approve</a>
                    <a onclick="return confirm('Do You Want To Reject Proposal')" href="{{ route('rejectProposal',['id'=>$proposal->id]) }}"class="btn btn-danger p-2 m-1 border-0 rounded-sm  bg-stone-200 hover:bg-cyan-950  hover:opacity-3 text-red-600 float-right text-sm">Reject</a>
                                          
                    </div>
                </div>
                @endforeach
                    </div>
                </div>
                {{$proposals}}
            </div>
            <!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content -->
@endsection


</container>
</body>
</html>
