@include('includes.head')


<body class=" leading-normal tracking-normal bg-[#F0F3F4] min-h-screen flex flex-col ">
  <!--Nav-->
  @include('includes.header')
 <section>
  <nav class="flex mx-3 mt-2 " aria-label="Breadcrumb">
    <ol class="inline-flex items-center space-x-1 md:space-x-3">
      <li class="inline-flex items-center">
        <a href="Home.html" class="inline-flex items-center text-sm font-medium text-cyan-950  underline  ">
          Home
        </a>
      </li>
      <li aria-current="page">
        <div class="flex items-center">
          <svg class="w-3 h-3 text-[#005299] mx-1" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 6 10">
            <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m1 9 4-4-4-4" />
          </svg>
          <span class="ml-1 text-sm font-medium text-[#0891B2] md:ml-2 ">Favorites List</span>
        </div>
      </li>
    </ol>
  </nav>




  @section('content')

  <!-- Content Header (Page header) -->
  <!-- Content Header (Page header) --><div class=" w-full flex justify-center mx-auto sm:rounded-lg text-sm flex-grow">
    <div class="w-full md:w-3/4 flex items-center justify-center md:mx-auto">
        <div class="w-6/12 md:w-10/12 p-2 flex items-center justify-start">
            <h1 class="text-left md:text-xl text-lg"> {{ __('Favorites list') }} </h1>
        </div>

        <div class="w-4/12 md:w-2/12 justify-end m-1 md:m-1">
            <a href="{{ url('/showProjects') }}">
                <button class="w-full md:w-10/12 md:px-1 py-2 border-0 rounded-sm mx-2 md:mx-1 items-center gradient  hover:bg-cyan-600 hover:cursor-pointer text-white text-xs">Browse Archives</button>
            </a>
        </div>
    </div>
</div>
<!-- /.content-header -->

<!-- Main content -->
<div class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    @if(Session::has('success'))
                    <div class="alert alert-success alert-dismissible show">
                        {{ session('success') }}
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    @endif
                    @if(Session::has('error'))
                    <div class="alert alert-danger alert-dismissible show">
                        {{ session('error') }}
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    @endif

                    <div class="hidden md:visible lg:visible md:flex flex-wrap justify-center text-sm text-left md:w-full w-11/12 mx-auto">
                        @forelse($favProjects as $fav)
                        <div class="w-96 md:w-80 p-6 bg-white border border-gray-200 rounded-lg shadow m-2 hover:bg-opacity-50 content">
                            <!-- for  -->

                            <div class="h-66">
                                <div class="h-56">
                                    <h2 class="text-lg font-bold text-cyan-950 mb-2 opacity-95">Project Details</h2>
                                    <div class="mb-2">
                                        <h1 class="text-md font-bold text-cyan-950 opacity-90">Title: </h1>
                                        <p class="text-gray-800 text-sm"> {{$fav->name}} </p>
                                    </div>
                                    <div class="mb-2">
                                        <h1 class="text-md font-bold text-cyan-950 opacity-90">Supervisor:</h1>
                                        <p class="text-gray-800 text-sm"> {{$fav->supervisor_name}} </p>
                                    </div>
                                    <div class="mb-2">
                                        <h1 class="text-md font-bold text-cyan-950 opacity-90">Research Specialization:</h1>
                                        <p class="text-gray-800 text-sm"> {{$fav->research_specialization}} </p>
                                    </div>
                                </div>
                                <div class="w-full flex flex-wrap items-center border-t-2 border-black-100 border-solid ">
                                    <div class="w-9/12 ">
                                        <a href="{{ route('readMore',['id'=>$fav->project_id]) }}" class="w-3/8 flex justify-start float-left px-5 py-2 text-md font-medium text-center text-white gradient rounded-full  hover:bg-cyan-600 mt-2">View </a>
                                    </div>
                                    <!-- view the project in the abstract page -->
                                    <div class="w-3/12 ">
                                        <a href="{{route('remove.fav',['id'=>$fav->project_id])}}" onclick="if(confirm('Are You Sure?')){}else{event.stopPropagation(); event.preventDefault();};" class="w-4/12 md:w-5/12 flex justify-end float-right p-2 border-0 rounded-full bg-stone-200 hover:bg-cyan-950 hover:opacity-3 text-red-600 text-sm mt-2"> <i class="fa fa-star text-red-600" aria-hidden="true"></i></a>
                                    </div>
                                    <!-- Delete from favorites list  -->
                                </div>
                            </div>
                        </div>
                        @empty
                        <div>
                            Empty Favourite List
                        </div>
                        @endforelse
                    </div>

                    <!-- in small screen -->
                    <div class="flex items-center justify-center">

                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-4 md:hidden lg:hidden">
    @forelse($favProjects as $fav)
        <div class="w-11/12 mx-auto bg-white space-y-3 p-4 rounded-lg shadow">
            <div class="w-full flex items-center space-x-2 text-sm">
                <div class="w-full">
                    <a href="{{ route('readMore',['id'=>$fav->project_id]) }}" class="text-cyan-950 font-bold ">{{$fav->name}}</a>
                </div>
            </div>
            <div class="text-sm text-gray-700">
                {{$fav->research_specialization}}
            </div>
            <div class="w-6/12 text-gray-500">{{$fav->supervisor_name}}</div>
            <div class="w-full flex flex-wrap float-right">
                <div class="w-10/12">
                    <a href="{{ route('readMore',['id'=>$fav->project_id]) }}" class="w-3/8 flex justify-start float-left px-5 py-2 text-md font-medium text-center text-white gradient rounded-full hover:bg-cyan-600 mt-2">View</a>
                </div>
                <div class="w-2/12">
                    <a href="{{route('remove.fav',['id'=>$fav->project_id])}}" onclick="if(confirm('Are You Sure?')){}else{event.stopPropagation(); event.preventDefault();};" class="w-4/12 md:w-5/12 flex justify-center float-right p-2 border-0 rounded-full bg-stone-200 hover:bg-cyan-950 hover:opacity-3 text-red-600 text-sm mt-2"> <i class="fa fa-star text-red-600" aria-hidden="true"></i></a>
                </div>
            </div>
        </div>
    @empty
        <div>
            Empty Favourite List
        </div>
    @endforelse
</div>
</div>

                    <!-- row -->
                </div>
                <!-- container-fluid -->
            </div>
            <!-- /.content -->
        </div>
    </div>
</div>


    

</section>
</body>

@include('includes.footer')

<script>
    var scrollpos = window.scrollY;
    var header = document.getElementById("header");
    var navcontent = document.getElementById("nav-content");
    var navaction = document.getElementById("navAction");
    var brandname = document.getElementById("brandname");
    var toToggle = document.querySelectorAll(".toggleColour");

    document.addEventListener("scroll", function() {
      /*Apply classes for slide in bar*/
      scrollpos = window.scrollY;

      if (scrollpos > 10) {
        header.classList.add("bg-[#F0F3F4] ");
        navaction.classList.remove("bg-[#F0F3F4] ");
        navaction.classList.add("gradient");
        navaction.classList.remove("text-gray-800");
        navaction.classList.add("text-white");
        //Use to switch toggleColour colours
        for (var i = 0; i < toToggle.length; i++) {
          toToggle[i].classList.add("text-gray-800");
          toToggle[i].classList.remove("text-white");
        }
        header.classList.add("shadow");
        navcontent.classList.remove("bg-gray-100");
        navcontent.classList.add("bg-[#F0F3F4] ");
      } else {
        header.classList.remove("bg-[#F0F3F4] ");
        navaction.classList.remove("gradient");
        navaction.classList.add("bg-[#F0F3F4] ");
        navaction.classList.remove("text-white");
        navaction.classList.add("text-gray-800");
        //Use to switch toggleColour colours
        for (var i = 0; i < toToggle.length; i++) {
          toToggle[i].classList.add("text-white");
          toToggle[i].classList.remove("text-gray-800");
        }

        header.classList.remove("shadow");
        navcontent.classList.remove("bg-[#F0F3F4] ");
        navcontent.classList.add("bg-gray-100");
      }
    });
  </script>
  <script>
    /*Toggle dropdown list*/
    /*https://gist.github.com/slavapas/593e8e50cf4cc16ac972afcbad4f70c8*/

    var navMenuDiv = document.getElementById("nav-content");
    var navMenu = document.getElementById("nav-toggle");

    document.onclick = check;

    function check(e) {
      var target = (e && e.target) || (event && event.srcElement);

      //Nav Menu
      if (!checkParent(target, navMenuDiv)) {
        // click NOT on the menu
        if (checkParent(target, navMenu)) {
          // click on the link
          if (navMenuDiv.classList.contains("hidden")) {
            navMenuDiv.classList.remove("hidden");
          } else {
            navMenuDiv.classList.add("hidden");
          }
        } else {
          // click both outside link and outside menu, hide menu
          navMenuDiv.classList.add("hidden");
        }
      }
    }

    function checkParent(t, elm) {
      while (t.parentNode) {
        if (t == elm) {
          return true;
        }
        t = t.parentNode;
      }
      return false;
    }
  </script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/flowbite/1.8.1/flowbite.min.js"></script>


</html>