@extends('admin.layouts.app')

@section('content')
    <!-- Content Header (Page header) -->
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0">{{ __('Users') }}</h1>
                </div><!-- /.col -->
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12">

                    <!-- <div class="alert alert-info">
                        Sample table page
                    </div> -->

                    <div class="card">
                        <div class="card-body p-0">

                           
<table class="min-w-full divide-y divide-gray-200">
    <thead>
        <tr>
            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Name</th>
            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Email</th>
            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Action</th>
        </tr>
    </thead>
    <tbody class="bg-white divide-y divide-gray-200">
        @foreach($users as $user)
            <tr>
                <td class="px-6 py-4 whitespace-nowrap">{{ $user->name }}</td>
                <td class="px-6 py-4 whitespace-nowrap">{{ $user->email }}</td>
                <td class="px-6 py-4 whitespace-nowrap">
                    <!-- Form to Update User Type -->
                    <form action="{{ url('updateType') }}" method="post" enctype="multipart/form-data">
                        @csrf
                        <div class="relative inline-block text-left">
                            <select name="userType" class="form-control" onchange="this.form.submit()" name="" id="">
                                <option @if($user->user_type =='admin') selected @endif value="admin">Admin</option>
                                <option @if($user->user_type =='superviser') selected @endif value="superviser">Superviser</option>
                                <option  @if($user->user_type =='student') selected @endif value="student">Student</option>
                             </select>
                        </div>
                        <!-- Hidden Input for User ID -->
                        <input type="hidden" name="userId" value="{{ $user->id }}">
                    </form>
                </td>
            </tr>
        @endforeach
    </tbody>
</table>

                        </div>
                        <!-- /.card-body -->

                        <div class="card-footer clearfix">
                            {{ $users->links() }}
                        </div>
                    </div>

                </div>
            </div>
            <!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content -->
@endsection